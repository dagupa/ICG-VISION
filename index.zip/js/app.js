    // ── VERSIÓN DE LA APLICACIÓN ───────────────────────────────────────────
    // Formato MAYOR.MEJORA.CORRECCIÓN
    // · MAYOR      : cambio de versión principal
    // · MEJORA     : nueva funcionalidad
    // · CORRECCIÓN : fix de errores
    const VERSION = '0.10.1';

    // Variable para guardado de progreso
        let hasUnsavedChanges = false;
    // Handle de fichero reemplazado por _saveDirHandle gestionado por IndexedDB (ver bloque Administrador)
    // Autoguardado: cada 10 cambios O cada 10 minutos (solo si hay cambios pendientes)
    let _autoSaveCount = 0;
    const AUTO_SAVE_THRESHOLD = 10;
    const AUTO_SAVE_INTERVAL_MS = 10 * 60 * 1000; // 10 minutos
    let _autoSaveTimer = null;

    function _startAutoSaveTimer() {
        if (_autoSaveTimer) clearInterval(_autoSaveTimer);
        _autoSaveTimer = setInterval(() => {
            if (hasUnsavedChanges) autoSaveToFolderOrBackup();
        }, AUTO_SAVE_INTERVAL_MS);
    }

    function registerChange() {
        hasUnsavedChanges = true;
        updateSaveButton();
        _autoSaveCount++;
        if (_autoSaveCount >= AUTO_SAVE_THRESHOLD) {
            _autoSaveCount = 0;
            autoSaveToFolderOrBackup();
        }
    }

    function _buildSaveData() {
        return {
            equipo: reportMetadata?.equipo || 'default',
            fechaExportacion: new Date().toISOString(),
            progress: progressMap,
            errors: errorsMap,
            rows: rawData
        };
    }

    function _getInternalSnapshotKey() {
        const equipo = reportMetadata?.equipo || 'default';
        return `ICGVision_AutoSnapshot_${equipo.replace(/\s+/g, '_')}`;
    }

    // Copia de seguridad silenciosa dentro del navegador (red de seguridad ante cierres
    // inesperados). No marca los datos como guardados ni desactiva el botón.
    function _writeLocalBackup() {
        try {
            if (!reportMetadata || !reportMetadata.equipo) return;
            saveProgress();
            saveErrors();
            localStorage.setItem(_getInternalSnapshotKey(), JSON.stringify(_buildSaveData()));
        } catch (e) {
            console.error('Copia de seguridad interna fallida:', e);
        }
    }

    // Autoguardado automático y transparente: si hay carpeta configurada con permiso,
    // escribe el JSON completo en ella sin molestar al usuario. Si no la hay, conserva
    // solo la copia interna y deja el botón "Guardar cambios" activo.
    async function autoSaveToFolderOrBackup() {
        _writeLocalBackup();
        if (!reportMetadata || !reportMetadata.equipo) return;
        if (!_saveDirHandle) return; // sin carpeta: el botón permanece activo
        try {
            // Autoguardado silencioso: solo si el permiso ya está concedido (sin diálogo).
            const perm = await _saveDirHandle.queryPermission({ mode: 'readwrite' });
            if (perm !== 'granted') return; // se guardará al pulsar "Guardar"
            await _writeJsonToDir(_saveDirHandle, _buildSaveData());
            hasUnsavedChanges = false;
            updateSaveButton();
        } catch (e) {
            // No se pudo autoguardar en carpeta: conservamos la copia interna y el botón
            // activo. NO borramos la carpeta configurada.
            console.error('Autoguardado en carpeta fallido:', e);
        }
    }
    // Variables para el easter eg
    let helpClickCount = 0;
   let helpClickTimer;
    // Función auxiliar para gestionar fallos de imagen y evitar conflictos de sintaxis en el HTML inyectado
       function handlePinError(imgElement) {
           const container = imgElement.parentElement;
           if (container) {
               container.innerHTML = '<i data-lucide="pin" class="w-3.5 h-3.5 text-sap-blue"></i>';
               if (window.lucide) lucide.createIcons();
           }
       }

       // CRIMP_PATHS e i18n se definen en js/master-data.js (cargado antes que este script)

       function isKN(c) {
           if (!c) return false;
           const v = c.toString().toUpperCase();
           return v.includes('KN-PELAR') || v.includes('PELADO') || v.startsWith('KN-');
       }
 
       function copyAndOpenWindchill(planoText) {
           if (!planoText || planoText === '---') return;
           const el = document.createElement('textarea');
           el.value = planoText + '*';
           document.body.appendChild(el);
           el.select();
           document.execCommand('copy');
           document.body.removeChild(el);
           window.open('https://windchill01.corp.knorr-bremse.com/Windchill/app/', '_blank');
       }
 
        let currentSortCol = null, sortAsc = true;
       let rawData = [], reportMetadata = {}, masterMap = { cables: {}, terminals: {}, sleeves: {} };
    let currentView = 'table', filterText = '', filterMarcaText = '', filterTerminalError = null, selectedMaterial = null, selectedConnectionPosition = null, currentLang = 'es';
       let summaryViewMode = 'cards'; 
       let currentZoom = 1, panX = 0, panY = 0, isPanning = false, resizingCol = null, startX, startWidth, thDragIdx = null, baseViewBox = { x: 0, y: 0, w: 0, h: 0 };
       let lastTouchX = 0, lastTouchY = 0, lastTouchDist = 0; 
       let detailPinSequence = [], detailPinDataMap = new Map(), currentDetailIndex = 0;
       let progressMap = {};
       let _dupPosicions = new Set(), _dupOrdenes = new Set(), _nonNumericLongitud = new Set();
    let _seccionMissingSet = new Set(), _termIncompatSet = new Set(), _termNotFoundSet = new Set();
    let _cableNotFoundSet = new Set(), _sleeveNotFoundSet = new Set();
       let _lastPinPopoverArgs = null;
       let _schemaSortedPins = [], _schemaPinDataCache = {};
       let _termTipTimeout = null;
       let errorsMap = {};
       let incidenciaModeActive = false;
       let currentSummaryStats = {};
 
       let columns = [
           { id: 'STATUS', key: 'status', visible: true, width: 45, es: 'OK', en: 'OK' },
           { id: 'A', key: 'posicion', visible: true, width: 60, es: 'POS.', en: 'POS.' },
           { id: 'B', key: 'orden', visible: true, width: 70, es: 'ORDEN', en: 'ORDER' },
           { id: 'C', key: 'cod_cable', visible: true, width: 120, es: 'ID CABLE', en: 'WIRE ID' },
           { id: 'D', key: 'seccion', visible: true, width: 70, es: 'SECC.', en: 'SECT.' },
           { id: 'E', key: 'longitud', visible: true, width: 80, es: 'LONGITUD', en: 'LENGTH' },
           { id: 'F', key: 'marcado', visible: true, width: 90, es: 'MARCADO', en: 'MARKED' },
           { id: 'G', key: 'cable_marca', visible: true, width: 130, es: 'MARCA', en: 'LABEL' },
           { id: 'H', key: 'de_elemento', visible: true, width: 100, es: 'DE ELEM.', en: 'FROM ELEM.' },
           { id: 'I', key: 'de_punto', visible: true, width: 80, es: 'DE PUNTO', en: 'FROM POINT' },
           { id: 'J', key: 'de_terminal', visible: true, width: 100, es: 'DE TERMINAL', en: 'FROM TERM.' },
           { id: 'K', key: 'de_manguito', visible: true, width: 100, es: 'DE MANGUITO', en: 'FROM SLEEVE' },
           { id: 'L', key: 'para_manguito', visible: true, width: 100, es: 'DE MARCA', en: 'FROM LABEL' },
           { id: 'M', key: 'para_elemento', visible: true, width: 100, es: 'PARA ELEM.', en: 'TO ELEM.' },
           { id: 'N', key: 'para_punto', visible: true, width: 80, es: 'PARA PUNTO', en: 'TO POINT' },
           { id: 'O', key: 'para_terminal', visible: true, width: 100, es: 'PARA TERMINAL', en: 'TO TERM.' },
           { id: 'P', key: 'observaciones', visible: true, width: 150, es: 'OBSERVACIONES', en: 'REMARKS' },
           { id: 'X', key: 'desc_cable', visible: false, width: 200, es: 'DESCRIPCIÓN CABLE', en: 'WIRE DESC' },
           { id: 'Y', key: 'desc_manguito', visible: false, width: 180, es: 'DESC. MANGUITO', en: 'SLEEVE DESC' },
           { id: 'Z', key: 'desc_terminal_de', visible: false, width: 180, es: 'DESC. TERM. DE', en: 'FROM TERM DESC' },
           { id: 'AA', key: 'desc_terminal_para', visible: false, width: 180, es: 'DESC. TERM. PARA', en: 'TO TERM DESC' }
       ];
 
       function getStorageKey() {
           const equipo = reportMetadata.equipo || 'default';
           return `ICGVision_Progress_${equipo.replace(/\s+/g, '_')}`;
       }
       function saveProgress() { try { localStorage.setItem(getStorageKey(), JSON.stringify(progressMap)); } catch (e) { console.error("Error saving progress", e); } }
       function loadProgress() { try { const stored = localStorage.getItem(getStorageKey()); progressMap = stored ? JSON.parse(stored) : {}; } catch (e) { progressMap = {}; } }
       function saveErrors() { try { localStorage.setItem(getStorageKey() + '_errors', JSON.stringify(errorsMap)); } catch (e) { console.error("Error saving errors", e); } }
       function loadErrors() { try { const stored = localStorage.getItem(getStorageKey() + '_errors'); errorsMap = stored ? JSON.parse(stored) : {}; } catch (e) { errorsMap = {}; } }

       // ── ADMINISTRADOR: carpeta de autoguardado (IndexedDB para persistir el DirectoryHandle) ──
     const _IDB_NAME = 'ICGVisionAdmin';
     const _IDB_STORE = 'handles';
     const _SAVE_DIR_NAME_KEY = 'ICGVision_SaveDirName';
     let _saveDirHandle = null;     // DirectoryHandle activo con permiso concedido (solo http/https)
     let _saveDirName = localStorage.getItem(_SAVE_DIR_NAME_KEY) || '';
     let _permWarned = false;       // Reservado para avisos de autoguardado

       function _openAdminDB() {
           return new Promise((resolve, reject) => {
               const req = indexedDB.open(_IDB_NAME, 1);
               req.onupgradeneeded = e => e.target.result.createObjectStore(_IDB_STORE);
               req.onsuccess = e => resolve(e.target.result);
               req.onerror = () => reject(req.error);
           });
       }

       async function _loadDirHandle() {
           try {
               const db = await _openAdminDB();
               return new Promise(resolve => {
                   const tx = db.transaction(_IDB_STORE, 'readonly');
                   const req = tx.objectStore(_IDB_STORE).get('saveDir');
                   req.onsuccess = () => resolve(req.result || null);
                   req.onerror = () => resolve(null);
               });
           } catch { return null; }
       }

       async function _storeDirHandle(handle) {
           try {
               const db = await _openAdminDB();
               return new Promise((resolve, reject) => {
                   const tx = db.transaction(_IDB_STORE, 'readwrite');
                   tx.objectStore(_IDB_STORE).put(handle, 'saveDir');
                   tx.oncomplete = resolve;
                   tx.onerror = () => reject(tx.error);
               });
           } catch (e) { console.error('Error guardando handle en IDB', e); }
       }

       async function _clearDirHandle() {
           try {
               const db = await _openAdminDB();
               return new Promise(resolve => {
                   const tx = db.transaction(_IDB_STORE, 'readwrite');
                   tx.objectStore(_IDB_STORE).delete('saveDir');
                   tx.oncomplete = resolve;
               });
           } catch { /* silencioso */ }
       }

       // Escribe el JSON completo (formateado) en la carpeta indicada con el nombre del equipo.
       async function _writeJsonToDir(dirHandle, data) {
           const fileName = `ICG_${(data.equipo || 'default').replace(/[^a-zA-Z0-9]/g, '_')}.json`;
           const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
           const writable = await fileHandle.createWritable();
           await writable.write(JSON.stringify(data, null, 2));
           await writable.close();
           return fileName;
       }

       // ── Carpeta de guardado configurada por el Administrador ────────────────────────
       // _saveDirHandle guarda la carpeta elegida. Se usa como punto de partida (startIn)
       // del diálogo de guardado para que el explorador se abra directamente en ella.

       function _updateAdminUI() {
           const label     = document.getElementById('adminSaveFolderLabel');
           const clearBtn  = document.getElementById('btnClearSaveFolder');
           const btnLabel  = document.getElementById('btnSelectFolderLabel');
           const selectBtn = document.getElementById('btnSelectFolder');
           const hint      = document.getElementById('adminFolderHint');
           if (!label) return;
           label.classList.remove('text-sap-secondaryText', 'text-sap-blue', 'text-amber-500', 'font-bold');

           const configuredFolderName = _saveDirHandle?.name || _saveDirName;

           if (configuredFolderName) {
               label.textContent = configuredFolderName;
               label.classList.add('text-sap-blue', 'font-bold');
               if (clearBtn) clearBtn.classList.remove('hidden');
               if (selectBtn) selectBtn.classList.remove('hidden');
               if (btnLabel) btnLabel.textContent = 'Cambiar carpeta';
               if (hint) hint.textContent = _isLocalFilePage()
                   ? 'Al guardar, el explorador intentará abrirse en esta carpeta. Si el navegador bloquea la escritura local, se usará Descargas como respaldo.'
                   : 'Al guardar, el explorador se abrirá directamente en esta carpeta. El usuario solo confirma.';
           } else {
               label.textContent = 'Sin configurar';
               label.classList.add('text-sap-secondaryText');
               if (clearBtn) clearBtn.classList.add('hidden');
               if (selectBtn) selectBtn.classList.remove('hidden');
               if (btnLabel) btnLabel.textContent = 'Configurar carpeta de guardado';
               if (hint) hint.textContent = 'Elige la carpeta donde se guardarán los archivos. Quedará memorizada para futuros guardados.';
           }
       }

       async function adminSelectSaveFolder() {
           if (!window.showDirectoryPicker) {
               showNotification('Tu navegador no soporta selección de carpeta. Usa Chrome o Edge.', 'error');
               return;
           }
           // En file:// Chrome no concede permiso de escritura sobre la carpeta y el
           // selector rechaza si se pide { mode: 'readwrite' }. Pedimos solo lectura: es
           // suficiente para mostrar el nombre y para usarla como punto de partida
           // (startIn) del diálogo de guardado. La escritura real ya tiene su respaldo.
           let handle;
           try {
               handle = await window.showDirectoryPicker();
           } catch (e) {
               if (e.name === 'AbortError') return; // el usuario canceló: sin aviso
               showNotification(`No se pudo seleccionar la carpeta: ${e.name}`, 'error');
               return;
           }
           _saveDirHandle = handle;
           _saveDirName = handle.name;
           localStorage.setItem(_SAVE_DIR_NAME_KEY, _saveDirName);
           _permWarned = false;
           _updateAdminUI();
           await _storeDirHandle(handle);
           showNotification(`Carpeta configurada: ${handle.name}`, 'success');
       }

       async function adminClearSaveFolder() {
           _saveDirHandle = null;
           _saveDirName = '';
           localStorage.removeItem(_SAVE_DIR_NAME_KEY);
           _permWarned = false;
           await _clearDirHandle();
           _updateAdminUI();
           showNotification('Carpeta de guardado eliminada', 'success');
       }

       async function _initAdminDirHandle() {
           try {
               const dirHandle = await _loadDirHandle();
               // Conservamos el handle para mostrar su nombre y usarlo como punto de
               // partida del diálogo de guardado, aunque el permiso deba reconcederse.
               if (dirHandle && !_saveDirHandle) {
                   _saveDirHandle = dirHandle;
                   _saveDirName = dirHandle.name || _saveDirName;
                   if (_saveDirName) localStorage.setItem(_SAVE_DIR_NAME_KEY, _saveDirName);
               }
           } catch (e) {
               console.error('No se pudo cargar la configuración de carpeta', e);
           }
           _updateAdminUI();
       }

       // Asegura permiso de escritura sobre la carpeta configurada DENTRO de un gesto del
       // usuario. Devuelve true si la carpeta queda lista para abrirse en el diálogo.
       async function _ensureDirPermission() {
           if (!_saveDirHandle) return false;
           try {
               let perm = await _saveDirHandle.queryPermission({ mode: 'readwrite' });
               if (perm !== 'granted') {
                   perm = await _saveDirHandle.requestPermission({ mode: 'readwrite' });
               }
               return perm === 'granted';
           } catch {
               return false;
           }
       }

       // ── PANEL ADMINISTRADOR (acceso protegido) ──
       const ADMIN_PASSWORD = 'IFA';

       function openAdminPanel() {
           // Cerrar el dropdown de ajustes
           const dd = document.getElementById('settingsDropdown');
           if (dd) dd.classList.add('hidden');
           // Resetear a estado de login (se pide contraseña cada vez)
           const modal = document.getElementById('adminModal');
           const loginStep = document.getElementById('adminLoginStep');
           const optionsStep = document.getElementById('adminOptionsStep');
           const pwInput = document.getElementById('adminPasswordInput');
           const pwError = document.getElementById('adminPasswordError');
           if (loginStep) loginStep.classList.remove('hidden');
           if (optionsStep) optionsStep.classList.add('hidden');
           if (pwError) pwError.classList.add('hidden');
           if (pwInput) pwInput.value = '';
           if (modal) { modal.classList.remove('hidden'); modal.classList.add('flex'); }
           if (window.lucide) lucide.createIcons();
           setTimeout(() => pwInput && pwInput.focus(), 50);
       }

       function closeAdminPanel() {
           const modal = document.getElementById('adminModal');
           if (modal) { modal.classList.add('hidden'); modal.classList.remove('flex'); }
       }

       async function adminCheckPassword() {
           const pwInput = document.getElementById('adminPasswordInput');
           const pwError = document.getElementById('adminPasswordError');
           if (!pwInput) return;
           if (pwInput.value === ADMIN_PASSWORD) {
               document.getElementById('adminLoginStep').classList.add('hidden');
               document.getElementById('adminOptionsStep').classList.remove('hidden');
               if (pwError) pwError.classList.add('hidden');
               if (window.lucide) lucide.createIcons();
               _updateAdminUI();
           } else {
               if (pwError) pwError.classList.remove('hidden');
               pwInput.value = '';
               pwInput.focus();
           }
       }
       // ── FIN PANEL ADMINISTRADOR ──
       
       function clearAllProgress() {
           if (!window.confirm('¿Seguro que quieres reiniciar el progreso?\nEsta acción no se puede deshacer.')) return;
           progressMap = {}; saveProgress(); hasUnsavedChanges = false; updateSaveButton(); updateGlobalProgress(); updateView(); toggleSettings();
           const toast = document.getElementById('notificationToast');
           if (toast) {
               const span = toast.querySelector('span'); if (span) span.innerText = "Progreso del equipo reiniciado correctamente";
               toast.classList.add('show'); setTimeout(() => toast.classList.remove('show'), 3000);
           }
       }
       // Función auxiliar para comprobar si un cable está terminado al 100%
       function isCableFinished(pos, elName = null) {
   const prog = progressMap[pos];
   if (!prog) return false;
   
   // Si no pasamos elemento, devolvemos el estado global (mantiene compatibilidad)
   if (!elName) return prog.de === true && prog.para === true;
   
   // Buscamos la fila para saber si el elemento es 'de' o 'para'
   const row = rawData.find(r => r.posicion === pos);
   if (!row) return false;
   
   const s = elName.toLowerCase();
   const esOrigen = (row.de_elemento || '').toLowerCase() === s;
   const esDestino = (row.para_elemento || '').toLowerCase() === s;
   
   // Si el elemento es ambos (puente), necesita ambos extremos marcados
   if (esOrigen && esDestino) return prog.de === true && prog.para === true;
   // Si solo es uno, basta con el estado de ese lado
   return esOrigen ? prog.de === true : (esDestino ? prog.para === true : false);
}
 
       // Nueva lógica de guardado: detecta automáticamente qué lado marcar
function toggleProgress(pos, contextElement = null) {
   if (!progressMap[pos]) progressMap[pos] = { de: false, para: false };
   
   if (contextElement) {
       const row = rawData.find(r => r.posicion === pos);
       if (!row) return;
       
       const s = contextElement.toLowerCase();
       // Cambia el estado (true/false) del extremo local de forma dinámica
       if ((row.de_elemento || '').toLowerCase() === s) progressMap[pos].de = !progressMap[pos].de;
       if ((row.para_elemento || '').toLowerCase() === s) progressMap[pos].para = !progressMap[pos].para;
   }
   
   saveProgress();
   registerChange();
   updateGlobalProgress();
   renderTable();
   
   // Si estamos dentro del asistente Modo Visión, forzamos el refresco inmediato de todo el panel
   if (!document.getElementById('detailModal').classList.contains('hidden')) {
       renderDetailStep();
       renderProgressList(); // Reevalúa asimétricamente los ticks verdes laterales
   }
   
   const graphModal = document.getElementById('graphModal');
   if (!graphModal.classList.contains('hidden')) {
       drawDiagram(document.getElementById('graphElementName').innerText);
   }
}
 
function markConnectionDone(posicion) {
   const elName = document.getElementById('graphElementName')?.innerText || '';
   toggleProgress(posicion, elName);
   if (_lastPinPopoverArgs) {
       try {
           const current = JSON.parse(decodeURIComponent(_lastPinPopoverArgs));
           if (current.type === 'pin' && _schemaSortedPins.length > 0) {
               // Comprobar si TODAS las conexiones del pin actual están ya marcadas
               const currentEl = elName.toLowerCase();
               const allDone = current.connections.every(cn => {
                   if (!cn.posicion) return true;
                   const prog = progressMap[cn.posicion] || { de: false, para: false };
                   const cableData = rawData.find(r => r.posicion === cn.posicion);
                   if (!cableData) return true;
                   if ((cableData.de_elemento || '').toLowerCase() === currentEl) return prog.de === true;
                   if ((cableData.para_elemento || '').toLowerCase() === currentEl) return prog.para === true;
                   return true;
               });
               if (allDone) {
                   // Todas hechas → saltar al siguiente punto de conexión
                   const idx = _schemaSortedPins.indexOf(current.pin);
                   const nextIdx = idx + 1;
                   if (nextIdx < _schemaSortedPins.length) {
                       const nextPin = _schemaSortedPins[nextIdx];
                       const nextPCs = _schemaPinDataCache[nextPin];
                       if (nextPCs) {
                           const nextArgs = encodeURIComponent(JSON.stringify({ type: 'pin', pin: nextPin, connections: nextPCs }));
                           showInfoPopover({ stopPropagation: () => {} }, nextArgs);
                           return;
                       }
                   }
               }
           }
       } catch (e) { /* fallback al comportamiento anterior */ }
       // Quedan conexiones pendientes o error → refrescar el popover actual
       showInfoPopover({ stopPropagation: () => {} }, _lastPinPopoverArgs);
   }
}

       function updateGlobalProgress() {
    if (!rawData || rawData.length === 0) return;

    // Cada cable físico representa 2 tareas de conexionado independientes (Origen y Destino)
    const totalConnections = rawData.length * 2;
    let completedConnections = 0;

    // Contabilizamos de forma independiente cada extremo realizado en el mapa de progreso
    rawData.forEach(r => {
        const prog = progressMap[r.posicion];
        if (prog) {
            if (prog.de === true) completedConnections++;
            if (prog.para === true) completedConnections++;
        }
    });

    // Cálculo del porcentaje basado en conexiones individuales reales
    const percent = totalConnections > 0 ? Math.round((completedConnections / totalConnections) * 100) : 0;

    // Actualización de elementos en la interfaz de usuario (UI)
    const progressBar = document.getElementById('globalProgressFill');
    const progressText = document.getElementById('globalProgressText');

    if (progressBar) progressBar.style.width = `${percent}%`;
    if (progressText) {
        progressText.innerText = `${completedConnections} de ${totalConnections} conexiones realizadas (${percent}%)`;
    }
}
       
       function updateErrorBadge() {
           const count = Object.keys(errorsMap).length;
           ['errorBadge', 'errorBadgeVision'].forEach(id => {
               const badge = document.getElementById(id);
               if (!badge) return;
               if (count > 0) { badge.textContent = count > 9 ? '9+' : count; badge.classList.remove('hidden'); }
               else { badge.classList.add('hidden'); }
           });
       }
 
       function toggleIncidenciasMenu() {
           const dd = document.getElementById('incidenciasDropdown');
           const btn = document.getElementById('btnIncidencias');
           const isOpen = !dd.classList.contains('hidden');
           dd.classList.toggle('hidden', isOpen);
           btn.classList.toggle('bg-red-500/10', !isOpen);
       }
 
       function toggleVisionIncidenciasMenu() {
           const dd = document.getElementById('visionIncidenciasDropdown');
           const btn = document.getElementById('btnVisionIncidencias');
           const isOpen = !dd.classList.contains('hidden');
           dd.classList.toggle('hidden', isOpen);
           btn.classList.toggle('bg-red-500/80', !isOpen);
       }
 
       function openIncidentFromVision() {
           toggleVisionIncidenciasMenu();
           if (!detailPinSequence || detailPinSequence.length === 0) {
               showNotification('No hay ningún punto seleccionado', 'error'); return;
           }
           const pin = detailPinSequence[currentDetailIndex];
           const connections = detailPinDataMap.get(pin);
           if (!connections || connections.length === 0) {
               showNotification('No hay cables en el punto activo', 'error'); return;
           }
           if (connections.length === 1) {
               openErrorModal(connections[0].posicion);
               return;
           }
           // Más de un cable: mostrar selector
           const list = document.getElementById('visionCableSelectList');
           list.innerHTML = connections.map(c => {
               const hasError = errorsMap[c.posicion] !== undefined;
               return `<button onclick="closeVisionCableSelect(); openErrorModal('${c.posicion}')"
                   class="w-full flex items-center gap-3 p-3 rounded-xl border transition-colors text-left
                       ${hasError
                           ? 'border-red-300 bg-red-50 dark:bg-red-900/20 hover:bg-red-100'
                           : 'border-sap-border dark:border-slate-600 bg-white dark:bg-slate-700 hover:bg-sap-blue/5'}">
                   <div class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0
                       ${hasError ? 'bg-red-100 dark:bg-red-900/40 text-red-500' : 'bg-sap-blue/10 text-sap-blue'}">
                       <i class="fas ${hasError ? 'fa-exclamation-triangle' : 'fa-plug'} text-xs"></i>
                   </div>
                   <div class="min-w-0">
                       <p class="text-sm font-bold text-sap-text dark:text-white truncate">${c.cable_marca || c.posicion}</p>
                       <p class="text-xs text-slate-500 dark:text-slate-400 truncate">Pos: ${c.posicion} · ${c.cod_cable || '—'}</p>
                   </div>
                   ${hasError ? '<span class="ml-auto text-[9px] font-bold text-red-500 uppercase">Con incidencia</span>' : ''}
               </button>`;
           }).join('');
           const modal = document.getElementById('visionCableSelectModal');
           modal.classList.remove('hidden');
           modal.classList.add('flex');
           if (window.lucide) lucide.createIcons();
       }
 
       function closeVisionCableSelect() {
           const modal = document.getElementById('visionCableSelectModal');
           modal.classList.add('hidden');
           modal.classList.remove('flex');
       }
 
       function activateIncidenciaMode() {
           incidenciaModeActive = true;
           const bar = document.getElementById('incidenciaModeBar');
           if (bar) { bar.classList.remove('hidden'); bar.classList.add('flex'); }
           toggleIncidenciasMenu();
           renderTable();
       }
 
       function deactivateIncidenciaMode() {
           incidenciaModeActive = false;
           const bar = document.getElementById('incidenciaModeBar');
           if (bar) { bar.classList.add('hidden'); bar.classList.remove('flex'); }
           renderTable();
       }
 
       // ── GESTIÓN DE ERRORES ─────────────────────────────────────────────────
       const ERROR_COLUMNS = [
           { key: 'posicion',         label: 'A — Posición' },
           { key: 'orden',            label: 'B — Orden dentro de la lista' },
           { key: 'cod_cable',        label: 'C — Cod. cable' },
           { key: 'seccion',          label: 'D — Sección' },
           { key: 'longitud',         label: 'E — Longitud' },
           { key: 'marcado',          label: 'F — Marcado' },
           { key: 'cable_marca',      label: 'G — Cable / Marca' },
           { key: 'de_elemento',      label: 'H — De Elemento' },
           { key: 'de_punto',         label: 'I — De Punto Conexión' },
           { key: 'de_terminal',      label: 'J — De Terminal' },
           { key: 'de_manguito',      label: 'K — De Manguito' },
           { key: 'para_manguito',    label: 'L — De Marca' },
           { key: 'para_elemento',    label: 'M — Para Elemento' },
           { key: 'para_punto',       label: 'N — Para Punto Conexión' },
           { key: 'para_terminal',    label: 'O — Para Terminal' },
           { key: 'observaciones',    label: 'P — Observaciones' }
       ];
 
       let _errorModalPosicion = null;
 
       function openErrorModal(posicion) {
           _errorModalPosicion = posicion;
           const row = rawData.find(r => r.posicion === posicion);
           if (!row) return;
           const existing = errorsMap[posicion] || {};
           document.getElementById('errorModalPosicion').textContent = posicion;
           const deleteBtn = document.getElementById('errorDeleteBtn');
           const saveBtn = document.querySelector('#errorModal button[onclick="saveError()"]');
           if (Object.keys(existing).length > 0) deleteBtn.classList.remove('hidden');
           else deleteBtn.classList.add('hidden');
           if (saveBtn) saveBtn.classList.remove('hidden');
           const fields = document.getElementById('errorModalFields');
           fields.innerHTML = ERROR_COLUMNS.map(col => {
               const original = row[col.key] || '';
               const changed = existing[col.key] !== undefined ? existing[col.key] : original;
               const isModified = existing[col.key] !== undefined;
               const isPosicion = col.key === 'posicion';
               return `<div class="flex flex-col gap-1">
                   <label class="text-xs font-semibold text-slate-500 dark:text-slate-400">${col.label}</label>
                   <div class="text-xs text-slate-400 dark:text-slate-500 mb-1">Original: <span class="font-mono">${original || '—'}</span></div>
                   <input type="text"
                       data-key="${col.key}"
                       value="${changed}"
                       placeholder="${original || '—'}"
                       ${isPosicion ? 'readonly' : ''}
                       class="w-full px-3 py-2 rounded-lg border text-xs font-mono transition-colors
                           ${isModified
                               ? 'border-red-400 bg-red-50 dark:bg-red-500/30 text-red-700 dark:text-red-300'
                               : 'border-sap-border dark:border-slate-600 bg-white dark:bg-slate-700 text-sap-text dark:text-slate-200'}
                           ${isPosicion ? 'bg-slate-100 dark:bg-slate-700 cursor-not-allowed' : ''}
                           focus:outline-none focus:ring-2 focus:ring-sap-blue/40"
                       oninput="highlightIfChanged(this, '${original}')">
               </div>`;
           }).join('');
           const modal = document.getElementById('errorModal');
           modal.classList.remove('hidden');
           modal.classList.add('flex');
       }
 
       function highlightIfChanged(input, original) {
           const changed = input.value !== original;
           input.classList.toggle('border-red-400', changed);
           input.classList.toggle('bg-red-50', changed);
           input.classList.toggle('dark:bg-red-500/30', changed);
           input.classList.toggle('text-red-700', changed);
           input.classList.toggle('border-sap-border', !changed);
           input.classList.toggle('bg-white', !changed);
       }
 
       function closeErrorModal() {
           _errorModalPosicion = null;
           const modal = document.getElementById('errorModal');
           modal.classList.add('hidden');
           modal.classList.remove('flex');
       }
 
       // Comprueba que un código de terminal exista en el maestro de crimpado (master-data.js).
       // Excepciones admitidas aunque no figuren en master-data.js.
       const KNOWN_TERMINAL_EXCEPTIONS = new Set([
           '641M054', '641M089', '641M10047', '641M10160', '641M10272', '641M10295', '641M110', '641M130',
           '641M144', '641M275', '641M280', '641M281', '641M289', '641M371', '641M860', '641M861', '641M862',
           '641M960', '641M964', '641M993', 'H0014682', '641M10294', '641M072', '641M073', '641M080',
           '641M10026', '641M10027', '641M10112', '641M10172', '641M10174', '641M10263', '641M115', '641M184',
           '641M267', '641M294', '641M295', '641M298', '641M302', '641M331', '641M351', '641M597', '641M598',
           '641M744', '641M830', '641M855', '695000'
       ]);
       function isValidTerminalCode(code) {
           if (!code) return true;
           const idToSearch = code.toString().trim().toUpperCase();
           if (idToSearch.startsWith('KN-PELAR') || KNOWN_TERMINAL_EXCEPTIONS.has(idToSearch)) return true;
           return crimpingMasterData.some(item => item.id.toString().toUpperCase() === idToSearch);
       }
       function isValidCableCode(code) {
           if (!code) return true;
           return VALID_CABLE_CODES.has(code.toString().trim().toUpperCase());
       }
       function isValidSleeveCode(code) {
           if (!code) return true;
           return VALID_SLEEVE_CODES.has(code.toString().trim().toUpperCase());
       }

       function saveError() {
           if (!_errorModalPosicion) return;
           const row = rawData.find(r => r.posicion === _errorModalPosicion);
           if (!row) return;
           const inputs = document.querySelectorAll('#errorModalFields input[data-key]');
           const seccionInput = document.querySelector('#errorModalFields input[data-key="seccion"]');
           const seccionValue = seccionInput?.value?.trim();
           for (const input of inputs) {
               const key = input.dataset.key;
               if (!['de_terminal', 'para_terminal', 'cod_cable', 'de_manguito'].includes(key)) continue;
               const terminalValue = input.value?.trim();
               const valid = key === 'cod_cable' ? isValidCableCode(terminalValue)
                   : key === 'de_manguito' ? isValidSleeveCode(terminalValue)
                   : isValidTerminalCode(terminalValue);
               if (!valid) {
                   showNotification('El código introducido no es correcto o no está dado de alta en la base de datos master-data.js', 'error');
                   input.focus();
                   return;
               }
               const compat = key === 'de_terminal' || key === 'para_terminal'
                   ? checkSectionCompatibility(terminalValue, seccionValue)
                   : null;
               if (compat && !compat.ok) {
                   showNotification('El terminal/pin introducido no es válido para la sección de este cable', 'error');
                   input.focus();
                   return;
               }
           }
           const changes = {};
           inputs.forEach(input => {
               const key = input.dataset.key;
               // Normalizamos a texto para evitar falsos cambios por tipo (number vs string).
               const original = String(row[key] ?? '');
               const current = String(input.value ?? '');
               if (current !== original) changes[key] = input.value;
           });
           if (Object.keys(changes).length === 0) {
               delete errorsMap[_errorModalPosicion];
           } else {
               errorsMap[_errorModalPosicion] = { ...changes };
           }
           saveErrors();
           registerChange();
           closeErrorModal();
           renderTable();
           updateErrorBadge();
           const msg = Object.keys(changes).length === 0
               ? 'Incidencia eliminada'
               : 'Incidencia registrada correctamente';
           showNotification(msg, 'success');
       }
 
       function deleteError() {
           if (!_errorModalPosicion) return;
           delete errorsMap[_errorModalPosicion];
           saveErrors();
           registerChange();
           closeErrorModal();
           renderTable();
           updateErrorBadge();
           showNotification('Registro de error eliminado', 'success');
       }
       // ── FIN GESTIÓN DE ERRORES ─────────────────────────────────────────────

       function exportConnectionListToTxt() {
           if (!rawData || rawData.length === 0) { showNotification('No hay datos cargados', 'error'); return; }
           const TXT_KEYS = [
               'posicion', 'orden', 'cod_cable', 'seccion', 'longitud',
               'marcado', 'cable_marca', 'de_elemento', 'de_punto', 'de_terminal',
               'de_manguito', 'para_manguito', 'para_elemento', 'para_punto', 'para_terminal', 'observaciones'
           ];
           const TXT_BLANK_IF = { de_terminal: ['S/T','S/M'], de_manguito: ['S/T','S/M'], para_terminal: ['S/T','S/M'] };
           // Elimina encabezado
           const firstDataIdx = rawData.findIndex(r => String(r.posicion).trim() !== '');
           const exportRows = firstDataIdx >= 0 ? rawData.slice(firstDataIdx) : rawData;
           const lines = exportRows.map(r => {
               const changes = errorsMap[r.posicion] || {};
               return TXT_KEYS.map(k => {
                   const v = changes[k] !== undefined ? changes[k] : (r[k] || '');
                   if (TXT_BLANK_IF[k] && TXT_BLANK_IF[k].includes(v)) return '';
                   return v;
               }).join('\t');
           });
           const content = lines.join('\r\n');
           const equipo = (reportMetadata.equipo || 'EQUIPO').replace(/[\\/:*?"<>|]/g, '_');
           const lista  = (reportMetadata.lista  || 'LISTA' ).replace(/[\\/:*?"<>|]/g, '_');
           const fileName = `${equipo}-${lista}.txt`;
           const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
           const url  = URL.createObjectURL(blob);
           const a    = document.createElement('a');
           a.href     = url;
           a.download = fileName;
           document.body.appendChild(a);
           a.click();
           document.body.removeChild(a);
           URL.revokeObjectURL(url);
           showNotification(`Exportado: ${fileName}`, 'success');
       }

       function exportSummaryToExcel() {
           if (!currentSummaryStats || Object.keys(currentSummaryStats).length === 0) return;
           const dataToExport = Object.entries(currentSummaryStats).map(([ref, val]) => ({ 'Código': ref, 'Descripción': val.desc || '---', 'Cantidad': val.count }));
           const wb = XLSX.utils.book_new(), ws = XLSX.utils.json_to_sheet(dataToExport); XLSX.utils.book_append_sheet(wb, ws, "Resumen");
           const typeLabel = currentView.split('-')[1] || 'Materiales', teamName = (reportMetadata.equipo || 'Export').replace(/\s+/g, '_');
           XLSX.writeFile(wb, `Resumen_${typeLabel}_${teamName}.xlsx`);
       }
 
       function exportErrorReport() {
           if (!rawData || rawData.length === 0) { showNotification('No hay datos cargados', 'error'); return; }
 
           const COL_KEYS = ['posicion','orden','cod_cable','seccion','longitud','marcado','cable_marca',
                             'de_elemento','de_punto','de_terminal','de_manguito','para_manguito',
                             'para_elemento','para_punto','para_terminal','observaciones','estado'];
           const COL_HEADERS = ['Posición','Orden dentro de la lista','Cod. cable','Sección','Longitud',
                                'Marcado','Cable / Marca','De Elemento','De Punto Conexión','De Terminal',
                                'De Manguito','De Marca','Para Elemento','Para Punto Conexión','Para Terminal','Observaciones','Estado'];
           const RED = { font: { color: { rgb: 'FF0000' }, bold: true } };
           const HEADER_STYLE = { font: { bold: true }, fill: { fgColor: { rgb: 'D9E1F2' } }, alignment: { horizontal: 'center' } };
           const ADDED_STYLE = { fill: { fgColor: { rgb: 'C6EFCE' } } };
           const DELETED_STYLE = { fill: { fgColor: { rgb: 'FFC7CE' } } };
           const MODIFIED_STYLE = { fill: { fgColor: { rgb: 'FFEB9C' } } };
           const ORDER_CHANGED_STYLE = { fill: { fgColor: { rgb: 'FFEB9C' } }, font: { color: { rgb: '9C6500' }, bold: true } };
 
           const allRows = rawData;
           const changedRows = allRows.filter(row => {
               const changes = errorsMap[row.posicion] || {};
               return row.deleted || row.added || row.orderChanged || Object.keys(changes).length > 0;
           });
           const wb = XLSX.utils.book_new();
           const wsData = [COL_HEADERS.map(h => ({ v: h, s: HEADER_STYLE }))];
 
           allRows.forEach(row => {
               const changes = errorsMap[row.posicion] || {};
               const hasError = Object.keys(changes).length > 0;
               const state = row.deleted ? 'Eliminado' : row.added ? 'Añadido' : row.orderChanged ? 'Renumerado' : row.modificado ? 'Modificado' : (hasError ? 'Con incidencia' : 'Sin cambios');
               const rowStyle = row.deleted ? DELETED_STYLE : row.added ? ADDED_STYLE : null;
               const cells = COL_KEYS.map(key => {
                   if (key === 'estado') {
                       return { v: state, s: rowStyle ? { ...rowStyle, font: { bold: true } } : { font: { bold: true } } };
                   }
                   const isChanged = changes[key] !== undefined;
                   const value = isChanged ? changes[key] : (row[key] || '');
                   const style = {};
                   if (rowStyle) Object.assign(style, rowStyle);
                   if (key === 'orden' && row.orderChanged) Object.assign(style, ORDER_CHANGED_STYLE);
                   if (row.deleted && key !== 'estado') Object.assign(style, DELETED_STYLE);
                   if (row.added && key !== 'estado') Object.assign(style, ADDED_STYLE);
                   if (isChanged) Object.assign(style, MODIFIED_STYLE, RED);
                   return Object.keys(style).length ? { v: value, s: style } : { v: value };
               });
               wsData.push(cells);
           });
 
           const ws = XLSX.utils.aoa_to_sheet(wsData);
           ws['!cols'] = COL_KEYS.map((_, i) => ({ wch: i === 0 ? 12 : i === 1 ? 20 : 16 }));
           XLSX.utils.book_append_sheet(wb, ws, 'Informe de Errores');
           const teamName = (reportMetadata.equipo || 'Export').replace(/\s+/g, '_');
           XLSX.writeFile(wb, `Informe_Errores_${teamName}.xlsx`);
           showNotification(`Informe exportado con ${allRows.length} filas y ${changedRows.length} cambios/incidencias registrados`, 'success');
       }

       function updateSaveButton() {
    const btn = document.getElementById('btnSave');
    if (!btn) return;
    const icon = btn.querySelector('i');
    const svg = btn.querySelector('svg'); // Capturamos el SVG real generado por Lucide
    
    if (hasUnsavedChanges) {
        btn.disabled = false;
        // Activado: Removemos estados inactivos
        btn.classList.remove('cursor-not-allowed', 'opacity-40');
        // Activado: Añadimos feedback visual verde al botón
        btn.classList.add('hover:bg-emerald-500/10', 'text-emerald-500', 'dark:text-emerald-400');
        btn.title = 'GUARDAR CAMBIOS';
        
        if (icon) {
            icon.classList.remove('text-slate-400', 'dark:text-slate-500');
            icon.classList.add('text-emerald-500', 'dark:text-emerald-400');
        }
        if (svg) {
            // Forzamos el color verde directamente en los atributos del gráfico vectorial (SVG)
            svg.classList.remove('text-slate-400', 'dark:text-slate-500');
            svg.classList.add('text-emerald-500', 'dark:text-emerald-400');
            svg.setAttribute('stroke', '#10b981'); 
            svg.style.stroke = '#10b981';
        }
    } else {
        btn.disabled = true;
        // Desactivado: Reintroducimos estados inactivos y gris de origen
        btn.classList.add('cursor-not-allowed', 'opacity-40');
        btn.classList.remove('hover:bg-emerald-500/10', 'text-emerald-500', 'dark:text-emerald-400');
        btn.title = 'GUARDAR CAMBIOS (No hay cambios pendientes)';
        
        if (icon) {
            icon.classList.remove('text-emerald-500', 'dark:text-emerald-400');
            icon.classList.add('text-slate-400', 'dark:text-slate-500');
        }
        if (svg) {
            // Devolvemos el SVG a su color gris neutro original de la interfaz de SAP
            svg.classList.remove('text-emerald-500', 'dark:text-emerald-400');
            svg.classList.add('text-slate-400', 'dark:text-slate-500');
            svg.setAttribute('stroke', '#94a3b8');
            svg.style.stroke = '#94a3b8';
        }
    }
}
	   function loadDataFromFile() {
    const input = document.getElementById('jsonLoadInput');
    if (!input) return;

    input.value = '';

    input.onchange = function(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(ev) {
            try {
                const data = JSON.parse(ev.target.result);

                // Validar estructura mínima
                if (!data.equipo || !data.progress) {
                    const toast = document.getElementById('notificationToast');
                    const span = toast.querySelector('span');
                    if (span) span.innerText = 'Archivo no válido o corrupto';
                    toast.classList.add('show');
                    setTimeout(() => toast.classList.remove('show'), 3500);
                    input.value = '';
                    return;
                }

                // Validar coincidencia de equipo
                if (data.equipo !== reportMetadata.equipo) {
                    const continuar = window.confirm(
                        `⚠️ El archivo pertenece al equipo "${data.equipo}" pero tienes cargado "${reportMetadata.equipo}".\n\n¿Deseas cargar el progreso igualmente?`
                    );
                    if (!continuar) {
                        input.value = '';
                        return;
                    }
                }

                // Restaurar datos
                progressMap = data.progress || {};
                errorsMap = data.errors || {};

                // Persistir en localStorage
                saveProgress();
                saveErrors();

       if (Array.isArray(data.rows)) {
           rawData = data.rows;
       } else if (Array.isArray(data.rawData)) {
           rawData = data.rawData;
       }
 
                renderTable();

                hasUnsavedChanges = false;
				updateSaveButton();
                input.value = '';

                // Notificación de éxito
                const fecha = data.fechaExportacion
                    ? new Date(data.fechaExportacion).toLocaleString('es-ES')
                    : '---';
                const toast = document.getElementById('notificationToast');
                const span = toast.querySelector('span');
                if (span) span.innerText = `Progreso restaurado correctamente (guardado el ${fecha})`;
                toast.classList.add('show');
                setTimeout(() => toast.classList.remove('show'), 3500);

            } catch (err) {
                console.error('Error leyendo JSON:', err);
                const toast = document.getElementById('notificationToast');
                const span = toast.querySelector('span');
                if (span) span.innerText = 'Error al leer el archivo';
                toast.classList.add('show');
                setTimeout(() => toast.classList.remove('show'), 3500);
                input.value = '';
            }
        };
        reader.readAsText(file);
    };

    input.click();
}
function showNotification(msg, type) {
    const toast = document.getElementById('notificationToast');
    if (!toast) return;
    const span = toast.querySelector('span');
    if (span) span.innerText = msg;
    toast.classList.remove('toast-success', 'toast-error', 'toast-warning');
    if (type === 'error') toast.classList.add('toast-error');
    else if (type === 'warning') toast.classList.add('toast-warning');
    else toast.classList.add('toast-success');
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), type === 'warning' ? 5000 : 3500);
}
function _markSaved() {
    hasUnsavedChanges = false;
    _autoSaveCount = 0;
    _permWarned = false;
    _startAutoSaveTimer();
    updateSaveButton();
}

// Descarga silenciosa sin ningún diálogo (el navegador guarda en la carpeta de descargas).
function _downloadJson(data) {
    const fileName = `ICG_${(data.equipo || 'default').replace(/[^a-zA-Z0-9]/g, '_')}.json`;
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = fileName;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function _isLocalFilePage() {
    return window.location && window.location.protocol === 'file:';
}

function _isFileSystemWriteBlocked(error) {
    return error && (error.name === 'NotAllowedError' || error.name === 'SecurityError');
}

function _finishWithDownloadFallback(data) {
    _downloadJson(data);
    _markSaved();
    showNotification('Archivo descargado en la carpeta de descargas del navegador ✓', 'success');
}

async function saveDataToFile() {
   try {
       if (!reportMetadata || !reportMetadata.equipo) {
           showNotification('No hay equipo cargado', 'error');
           return;
       }

       // Copia de seguridad interna siempre, antes de intentar escribir en disco.
       _writeLocalBackup();

       const data = _buildSaveData();
       const json = JSON.stringify(data, null, 2);
       const fileName = `ICG_${reportMetadata.equipo.replace(/[^a-zA-Z0-9]/g, '_')}.json`;

       // ── Diálogo de guardado abierto en la carpeta configurada por el Administrador ───
       if (window.showSaveFilePicker) {
           const opts = {
               suggestedName: fileName,
               types: [{ description: 'Archivo JSON', accept: { 'application/json': ['.json'] } }]
           };
           // El explorador se abre en la carpeta configurada (startIn solo necesita el
           // handle, no permiso). En file:// la escritura está bloqueada y se resuelve con
           // el respaldo de descarga; en http/localhost exigimos permiso para createWritable.
           if (_saveDirHandle) {
               if (_isLocalFilePage() || await _ensureDirPermission()) {
                   opts.startIn = _saveDirHandle;
               }
           }

           let fileHandle;
           try {
               fileHandle = await window.showSaveFilePicker(opts);
           } catch (e) {
               // El usuario pulsó "Cancelar": NO se ha guardado nada. Botón sigue activo.
               if (e.name === 'AbortError') {
                   showNotification('Guardado CANCELADO. Los cambios siguen pendientes ⚠️', 'warning');
                   return;
               }
               throw e;
           }

           // El usuario confirmó: escribimos realmente el archivo.
           try {
               const writable = await fileHandle.createWritable();
               await writable.write(json);
               await writable.close();
           } catch (e) {
               console.error('Error al escribir el archivo:', e);
               if (_isFileSystemWriteBlocked(e)) {
                   _finishWithDownloadFallback(data);
                   return;
               }
               showNotification('No se pudo escribir el archivo. Los cambios siguen pendientes ⚠️', 'error');
               return;
           }

           _markSaved();
           showNotification('Datos guardados correctamente ✓', 'success');
           return;
       }

       // ── Fallback (navegadores sin File System Access API) ───────────────────────────
       _finishWithDownloadFallback(data);

   } catch (e) {
       console.error('Error guardando archivo:', e);
       showNotification('Error al guardar archivo. Los cambios siguen pendientes ⚠️', 'error');
   }
}

function getNextPosicion() {
    if (!rawData || rawData.length === 0) return '1';
    const numbers = rawData.map(r => parseInt(r.posicion, 10)).filter(n => !isNaN(n));
    return String(numbers.length ? Math.max(...numbers) + 1 : 1);
}

function openAddCableModal() {
    const modal = document.getElementById('cableCrudModal');
    if (!modal) return;
    document.getElementById('crudModalTitle').innerText = 'Añadir Cable Nuevo';
    document.getElementById('crudPosicion').value = getNextPosicion();
    document.getElementById('crudOrden').value = '';
    document.getElementById('crudCodCable').value = '';
    document.getElementById('crudSeccion').value = '';
    document.getElementById('crudLongitud').value = '';
    document.getElementById('crudMarcado').value = '';
    document.getElementById('crudCableMarca').value = '';
    document.getElementById('crudDeElemento').value = '';
    document.getElementById('crudDePunto').value = '';
    document.getElementById('crudDeTerminal').value = '';
    document.getElementById('crudDeManguito').value = '';
    document.getElementById('crudParaElemento').value = '';
    document.getElementById('crudParaPunto').value = '';
    document.getElementById('crudParaTerminal').value = '';
    document.getElementById('crudParaManguito').value = '';
    document.getElementById('crudObservaciones').value = '';
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeCableModal() {
    const modal = document.getElementById('cableCrudModal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

function shiftOrdersDown(startOrder) {
    for (let i = rawData.length - 1; i >= 0; i -= 1) {
        const row = rawData[i];
        const currentOrder = parseInt(row.orden, 10);
        if (!isNaN(currentOrder) && currentOrder >= startOrder) {
            row.orden = String(currentOrder + 1);
            row.modificado = true;
        }
    }
}

function normalizeOrdenes() {
    if (!rawData || rawData.length === 0) return;
    rawData.sort((a, b) => {
        const aNum = parseInt(a.orden, 10);
        const bNum = parseInt(b.orden, 10);
        if (!isNaN(aNum) && !isNaN(bNum)) return aNum - bNum;
        if (!isNaN(aNum)) return -1;
        if (!isNaN(bNum)) return 1;
        return String(a.posicion).localeCompare(String(b.posicion), undefined, { numeric: true });
    });
    rawData.forEach((row, index) => {
        const targetOrder = String(index + 1);
        if (String(row.orden) !== targetOrder) {
            row.orden = targetOrder;
            row.modificado = true;
            row.orderChanged = true;
        }
    });
}

function openDeleteCableModal() {
    const modal = document.getElementById('deleteCableModal');
    if (!modal) return;
    const input = document.getElementById('deleteCablePos');
    if (input) input.value = '';
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeDeleteCableModal() {
    const modal = document.getElementById('deleteCableModal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

function confirmDeleteCable() {
    const input = document.getElementById('deleteCablePos');
    if (!input) return;
    const posicion = input.value?.trim();
    if (!posicion) {
        showNotification('Introduce una POS válida para eliminar el cable', 'error');
        return;
    }
    const index = rawData.findIndex(r => String(r.posicion) === posicion);
    if (index === -1) {
        showNotification(`No se encontró la posición ${posicion}`, 'error');
        return;
    }
    const confirmed = window.confirm(`¿Deseas eliminar completamente el cable con POS ${posicion}? Esta acción no se puede deshacer.`);
    if (!confirmed) return;
    const row = rawData[index];
    row.deleted = true;
    row.modificado = true;
    delete errorsMap[posicion];
    delete progressMap[posicion];
    registerChange();
    renderTable();
    updateErrorBadge();
    closeDeleteCableModal();
    showNotification(`Cable POS ${posicion} marcado como eliminado`, 'success');
}

function saveIncidencia() {
    const posicion = document.getElementById('crudPosicion')?.value?.trim();
    const ordenValue = document.getElementById('crudOrden')?.value?.trim();
    const cod_cable = document.getElementById('crudCodCable')?.value?.trim();
    const seccion = document.getElementById('crudSeccion')?.value?.trim();
    const longitud = document.getElementById('crudLongitud')?.value?.trim();
    const marcado = document.getElementById('crudMarcado')?.value?.trim();
    const cable_marca = document.getElementById('crudCableMarca')?.value?.trim();
    const de_elemento = document.getElementById('crudDeElemento')?.value?.trim();
    const de_punto = document.getElementById('crudDePunto')?.value?.trim();
    const de_terminal = document.getElementById('crudDeTerminal')?.value?.trim();
    const de_manguito = document.getElementById('crudDeManguito')?.value?.trim();
    const para_elemento = document.getElementById('crudParaElemento')?.value?.trim();
    const para_punto = document.getElementById('crudParaPunto')?.value?.trim();
    const para_terminal = document.getElementById('crudParaTerminal')?.value?.trim();
    const para_manguito = document.getElementById('crudParaManguito')?.value?.trim();
    const observaciones = document.getElementById('crudObservaciones')?.value?.trim();

    if (!posicion || !ordenValue) {
        showNotification('POS y Orden son obligatorios para añadir el cable', 'error');
        return;
    }

    const orden = parseInt(ordenValue, 10);
    if (isNaN(orden) || orden < 1) {
        showNotification('Orden debe ser un número entero válido mayor que 0', 'error');
        return;
    }

    const existsOrder = rawData.some(r => parseInt(r.orden, 10) === orden);
    if (existsOrder) {
        const applyShift = window.confirm(
            `El orden ${orden} ya existe. Pulsa Aceptar para desplazar hacia abajo los registros con orden >= ${orden} y reservar este lugar.`
        );
        if (!applyShift) {
            showNotification('Operación cancelada. Ajusta el orden antes de volver a intentar.', 'error');
            return;
        }
        shiftOrdersDown(orden);
    }

    const newRow = {
        posicion,
        orden: String(orden),
        cod_cable: cod_cable || '',
        seccion: seccion || '',
        longitud: longitud || '',
        marcado: marcado || '',
        cable_marca: cable_marca || '',
        de_elemento: de_elemento || '',
        de_punto: de_punto || '',
        de_terminal: de_terminal || '',
        de_manguito: de_manguito || '',
        para_elemento: para_elemento || '',
        para_punto: para_punto || '',
        para_terminal: para_terminal || '',
        para_manguito: para_manguito || '',
        observaciones: observaciones || '',
        modificado: true,
        added: true
    };

    rawData.push(newRow);
    normalizeOrdenes();
    registerChange();
    renderTable();
    closeCableModal();
    showNotification('Cable añadido correctamente y orden actualizado', 'success');
}

function deleteCableComplete() {
    const posicion = window.prompt('Introduce la POS del cable a eliminar:');
    if (!posicion) return;
    const posTrim = posicion.trim();
    const index = rawData.findIndex(r => String(r.posicion) === posTrim);
    if (index === -1) {
        showNotification(`No se encontró la posición ${posTrim}`, 'error');
        return;
    }
    const confirmed = window.confirm(`¿Deseas eliminar completamente el cable con POS ${posTrim}? Esta acción no se puede deshacer.`);
    if (!confirmed) return;
    const row = rawData[index];
    row.deleted = true;
    row.modificado = true;
    delete errorsMap[posTrim];
    delete progressMap[posTrim];
    registerChange();
    renderTable();
    updateErrorBadge();
    showNotification(`Cable POS ${posTrim} marcado como eliminado`, 'success');
}
       async function exportSleevesToZip(mode = 'download') {
           if (!rawData || rawData.length === 0) return;
           const sleeveData = rawData.filter(r => r.de_manguito && r.de_manguito.toUpperCase() !== 'S/M');
           if (sleeveData.length === 0) return;
           const zip = new JSZip(), groupedSleeves = {};
           sleeveData.forEach(r => { const ref = r.de_manguito.trim(); if (!groupedSleeves[ref]) groupedSleeves[ref] = []; groupedSleeves[ref].push(r); });
           const cleanText = (val) => String(val || "").replace(/,/g, "").trim(), sanitize = (name) => name.replace(/[^a-zA-Z0-9]/g, '').substring(0, 15);
           const teamPrefix = sanitize(reportMetadata.equipo || 'EQ');
          Object.keys(groupedSleeves).forEach(ref => {
               // Se inicializa con una cadena vacía para que la primera línea sea un salto de línea al unir con \r\n
               let contentLines = [""]; 
               groupedSleeves[ref].forEach(r => {
                   const marca = cleanText(r.cable_marca), o = `${cleanText(r.de_elemento)} ${cleanText(r.de_punto)}`, d = `${cleanText(r.para_elemento)} ${cleanText(r.para_punto)}`;
                   contentLines.push([marca, o, "", d, o, marca, d].join(","));
               });
               zip.file(`${teamPrefix}-${sanitize(ref)}.txt`, contentLines.join("\r\n"));
           });
           const zipBlob = await zip.generateAsync({ type: "blob" });
           const zipName = `${(reportMetadata.equipo || 'EQUIPO').replace(/[^a-zA-Z0-9]/g, '_')}.zip`;
           
           // Acción 1: Iniciar la descarga del archivo ZIP
           const a = document.createElement('a'); 
           a.href = URL.createObjectURL(zipBlob); 
           a.download = zipName;
           document.body.appendChild(a); 
           a.click(); 
           document.body.removeChild(a);
           
           // Acción 2 (Opcional): Abrir Outlook sin navegar fuera de la página
           if (mode === 'outlook') {
               const toast = document.getElementById('notificationToast');
               const span = toast.querySelector('span');
               span.innerText = "Confirmando descarga... Abriendo Outlook en breve";
               toast.classList.add('show');
 
               setTimeout(() => {
                   const subject = encodeURIComponent(`Archivos de Marcado - ${reportMetadata.equipo || 'Equipo'}`);
                   const body = encodeURIComponent(`Hola,\n\nSe han generado los archivos de marcado para el equipo: ${reportMetadata.equipo || '---'}.\n\n[ADJUNTA AQUÍ EL ARCHIVO "${zipName}" DE TU CARPETA DE DESCARGAS]\n\nSaludos.`);
                   const mailto = `mailto:?subject=${subject}&body=${body}`;
                   
                   // Técnica de Iframe invisible para mailto (previene redirección forzada del navegador)
                   const iframe = document.createElement("iframe");
                   iframe.style.display = "none";
                   iframe.src = mailto;
                   document.body.appendChild(iframe);
                   setTimeout(() => document.body.removeChild(iframe), 100);
 
                   // Restaurar UI
                   span.innerText = "Archivo generado y guardado en carpeta de descargas";
                   setTimeout(() => toast.classList.remove('show'), 2000);
               }, 2000); 
           } else {
               document.getElementById('notificationToast').classList.add('show'); 
               setTimeout(() => document.getElementById('notificationToast').classList.remove('show'), 3000);
           }
       }
function toggleMobileViewMenu() {
   const dd = document.getElementById('mobileViewDropdown');
   dd.classList.toggle('hidden');
}
function closeMobileViewMenu() {
   const dd = document.getElementById('mobileViewDropdown');
   dd.classList.add('hidden');
}
       function toggleSidebar() {
   const sidebar = document.getElementById('mainSidebar');
   const overlay = document.getElementById('sidebarOverlay');
   const isMobile = window.innerWidth < 768;
   if (isMobile) {
       const isOpen = sidebar.classList.contains('sidebar-open');
       sidebar.classList.toggle('sidebar-open', !isOpen);
       if (overlay) overlay.classList.toggle('hidden', isOpen);
   } else {
       sidebar.classList.toggle('hidden');
   }
}
function toggleToolbarFilters() {
   const panel = document.getElementById('toolbarFilterPanel');
   const btn = document.getElementById('btnToggleFilters');
   const isHidden = panel.classList.contains('hidden');
   panel.classList.toggle('hidden', !isHidden);
   panel.classList.toggle('flex', isHidden);
   btn.classList.toggle('text-sap-blue', isHidden);
   btn.classList.toggle('bg-sap-blue/10', isHidden);
}
function clearAllFiltersMobile() {
   document.getElementById('filterInputMobile').value = '';
   document.getElementById('filterMarcaInputMobile').value = '';
   document.getElementById('globalSearchInputMobile').value = '';
   clearAllFilters();
}
       function toggleSettings() { const el = document.getElementById('settingsDropdown'); if (el) el.classList.toggle('hidden'); }
       function toggleHelp() { const el = document.getElementById('helpModal'); if (el) { el.classList.toggle('hidden'); el.classList.toggle('flex'); } }
       function toggleDarkMode() { 
           const isDark = document.documentElement.classList.toggle('dark');
           const label = document.getElementById('themeLabel'); 
           if (label) label.innerText = isDark ? 'Modo Claro' : 'Modo Oscuro';
           // Persistencia de la elección
           localStorage.setItem('ICGVision_Theme', isDark ? 'dark' : 'light');
		   // Ocultamos el menú de ajustes inmediatamente tras conmutar el tema visual
		   document.getElementById('settingsDropdown')?.classList.add('hidden');
       }
	  
       function toggleFullScreen() { const d = document, el = d.documentElement; if (!d.fullscreenElement) { (el.requestFullscreen || el.webkitRequestFullscreen).call(el); } else { d.exitFullscreen(); } }
       function showLanding() { 
           const lp = document.getElementById('landingPage'); lp.classList.remove('hidden'); lp.style.opacity = '1'; 
           const breaker = document.getElementById('landingBreaker'); if (breaker) breaker.classList.remove('is-on'); 
           const eye = document.getElementById('landingEye'); if (eye) eye.classList.remove('eye-on'); 
           const fileInput = document.getElementById('csvInputLanding'); if (fileInput) fileInput.value = ''; 
       }
 
       function toggleColConfig() { 
           const el = document.getElementById('colConfigDropdown'); 
           if (el) {
               if (el.classList.contains('hidden')) {
                   renderColumnConfig();
               }
               el.classList.toggle('hidden'); 
           }
       }
 
       function renderColumnConfig() { 
           const list = document.getElementById('columnConfigConfigList'); 
           if (!list) return; 
           list.innerHTML = columns.map(c => `<div class="flex items-center justify-between p-2 border-b border-sap-border/50 text-xs text-sap-text dark:text-white"><span>${c[currentLang] || c.en}</span><button onclick="toggleColumn('${c.id}')" class="text-sap-blue p-1 hover:bg-sap-blue/10 rounded"><i data-lucide="${c.visible ? 'eye' : 'eye-off'}" class="w-4 h-4"></i></button></div>`).join(''); 
           lucide.createIcons(); 
       }
 
       function toggleColumn(id) { 
   const c = columns.find(x => x.id === id); 
   if (c) { 
       c.visible = !c.visible; 
       updateView(); 
       renderColumnConfig(); // Forzamos el repintado inmediato del ojo (abierto/cerrado)
   } 
}
       function openDetailMode() {
           const elN = filterText.trim(); if (!elN) return;
           const s = elN.toLowerCase(), inputs = rawData.filter(r => (r.para_elemento||'').toLowerCase() === s), outputs = rawData.filter(r => (r.de_elemento||'').toLowerCase() === s);
           const pinMap = new Map(); inputs.forEach(c => { if (!pinMap.has(c.para_punto)) pinMap.set(c.para_punto, []); pinMap.get(c.para_punto).push({ ...c, type: 'in' }); });
           outputs.forEach(c => { if (!pinMap.has(c.de_punto)) pinMap.set(c.de_punto, []); pinMap.get(c.de_punto).push({ ...c, type: 'out' }); });
           detailPinSequence = Array.from(pinMap.keys()).sort((a, b) => a.localeCompare(b, undefined, {numeric: true})); detailPinDataMap = pinMap; currentDetailIndex = 0;
           if (detailPinSequence.length === 0) return;
           document.getElementById('detailElementName').innerText = elN.toUpperCase(); document.getElementById('detailModal').classList.remove('hidden'); document.getElementById('detailModal').classList.add('flex');
           renderDetailStep(); renderProgressList();
       }
       function closeDetailMode() {
    document.getElementById('detailModal').classList.add('hidden');
    const s = filterText.trim();
    if (s) drawDiagram(s);
    updateView();
}

// LOGICA COLOR MANGUITOS
const MANGUITOS_BLANCOS = [
    '649D20021', '649D20022', '649D20023', '649964', '649962', 
    '649963', '649965', '649966', '649D20002', '649D20000', 
    '649D20001', '649D20003'
];

function getManguitoBgClass(codigo) {
    if (!codigo) return 'border-black/30 bg-[#FFFF99]';
    const cleanCode = codigo.toString().trim().toUpperCase();
    if (MANGUITOS_BLANCOS.includes(cleanCode)) {
        return 'border-black bg-white';
    }
    return 'border-black/30 bg-[#FFFF99]';
}

function getHoleRightClass(codigo) {
    if (!codigo) return 'bg-gradient-to-l from-yellow-600 to-[#FFFF99]';
    const cleanCode = codigo.toString().trim().toUpperCase();
    if (MANGUITOS_BLANCOS.includes(cleanCode)) {
        return 'bg-gradient-to-l from-gray-400 to-white';
    }
    return 'bg-gradient-to-l from-yellow-600 to-[#FFFF99]';
}

function renderDetailStep() {
   const pin = detailPinSequence[currentDetailIndex], connections = detailPinDataMap.get(pin);
   const currentElName = document.getElementById('detailElementName').innerText.toLowerCase();
   
   document.getElementById('currentPinLabel').innerText = pin; 
   document.getElementById('pinCounter').innerText = `PASO ${currentDetailIndex + 1} DE ${detailPinSequence.length}`;
   document.getElementById('btnPrevDetail').disabled = currentDetailIndex === 0; 
   
   const btnNext = document.getElementById('btnNextDetail');
   const isLastStep = currentDetailIndex === detailPinSequence.length - 1;
 
   if (isLastStep) {
       btnNext.innerHTML = 'TERMINAR <i data-lucide="check-circle" class="w-8 h-8"></i>';
       btnNext.classList.remove('bg-sap-blue');
       btnNext.classList.add('bg-emerald-500');
       btnNext.title = "Finalizar elemento y volver al esquema";
   } else {
       btnNext.innerHTML = 'SIGUIENTE <i data-lucide="chevron-right" class="w-8 h-8"></i>';
       btnNext.classList.remove('bg-emerald-500');
       btnNext.classList.add('bg-sap-blue');
       btnNext.title = "Siguiente punto de conexión";
   }
   btnNext.disabled = false;
 
   document.getElementById('progressFill').style.width = `${((currentDetailIndex + 1) / detailPinSequence.length) * 100}%`;
   
   document.getElementById('currentPinCables').innerHTML = connections.map(c => {
       const isOut = c.type === 'out';
       const termOrig = isOut ? c.de_terminal : c.para_terminal;
       const isPseudo = isKN(termOrig);
       
       // --- CONTROL ANTICRUZADO ESTRICTO PARA MANGUITOS EN MODO VISION ---
       // La única columna fiable de manguito es de_manguito (K).
       // para_manguito (L = "De Marca") no es un manguito y no debe usarse como tal.
       const rawM = c.de_manguito || "";
       const m = (rawM && rawM !== 'S/M' && rawM !== 'S/E' && rawM !== c.cable_marca) ? rawM : "S/M";
       // ------------------------------------------------------------------
       
       const peer = isOut ? c.para_elemento : c.de_elemento;
       const prog = progressMap[c.posicion] || { de: false, para: false };
       const row = rawData.find(r => r.posicion === c.posicion);
       
       let isCurrentSideOk = false;
       if (row) {
           if ((row.de_elemento || '').toLowerCase() === currentElName) isCurrentSideOk = prog.de === true;
           else if ((row.para_elemento || '').toLowerCase() === currentElName) isCurrentSideOk = prog.para === true;
       }
 
       const obs = c.observaciones && c.observaciones !== "---" ? c.observaciones : "";
       const crimpData = getCrimpingInfo(termOrig, c.seccion);
       const sectionCheck = !isPseudo ? checkSectionCompatibility(termOrig, c.seccion) : null;
       const defaultSvg = `<svg viewBox="0 0 64 32" class="w-full h-full text-slate-600"><rect x="2" y="8" width="25" height="16" rx="2" fill="#ef4444"/><circle cx="45" cy="16" r="10" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="45" cy="16" r="4" fill="currentColor"/><path d="M25 16 L35 16" stroke="currentColor" stroke-width="6" stroke-linecap="round"/></svg>`;
 
       return `<div class="bg-sap-card dark:bg-sap-darkCard p-6 rounded-2xl border-l-8 ${isOut ? 'border-l-sap-blue' : 'border-l-emerald-500'} shadow-xl flex flex-col gap-4 ${isCurrentSideOk ? 'opacity-50 ring-2 ring-[#10b981]/30' : ''}">
           <div class="flex justify-between items-start text-left">
               <span class="px-3 py-1 bg-sap-shell/10 rounded text-[10px] font-black uppercase text-sap-secondaryText">${isOut?'Salida':'Entrada'}</span>
               <span class="text-2xl font-black text-sap-blue">${c.cable_marca}</span>
           </div>
           <div class="grid grid-cols-2 gap-4"><div><p class="text-[9px] font-bold uppercase opacity-60">ID</p><p class="text-sm font-bold truncate">${c.cod_cable}</p></div><div><p class="text-[9px] font-bold uppercase opacity-60">Secc.</p><p class="text-sm font-bold">${c.seccion} mm²</p></div></div>
           <div class="p-3 bg-sap-shell/5 rounded-xl flex items-center gap-3"><div class="w-10 h-10 bg-sap-blue/10 flex items-center justify-center rounded-lg text-sap-blue"><i data-lucide="arrow-right-left" class="w-5 h-5"></i></div><div class="min-w-0"><p class="text-[9px] font-bold uppercase opacity-60">${isOut?'Destino':'Origen'}</p><p class="text-base font-black truncate text-sap-blue">${peer}</p></div></div>
           <div class="p-3 bg-sap-bg dark:bg-slate-900 rounded-xl flex items-center gap-3">
               ${!isPseudo ? `<div class="w-12 h-10 flex items-center justify-center shrink-0"><img src="${CRIMP_PATHS.terminales}${termOrig.trim()}.jpg" class="max-h-full max-w-full object-contain" onerror="handlePinError(this)"></div>` : ''}
               <div class="min-w-0 flex-1">
                   <p class="text-[9px] font-bold uppercase opacity-60">${isPseudo?'Instrucción':'Terminal'}</p>
                   <p class="text-base font-black truncate">${isPseudo?termOrig.substring(3):termOrig}</p>
                   <p class="text-[10px] text-sap-blue italic truncate">${masterMap.terminals[termOrig?.trim()]||""}</p>
               </div>
               ${crimpData ? `<button onclick="openCrimpingModal('${termOrig}', '${c.seccion}')" class="p-2 bg-sap-blue/10 text-sap-blue rounded-full hover:bg-sap-blue hover:text-white transition-all shadow-sm"><i data-lucide="wrench" class="w-4 h-4"></i></button>` : ''}
           </div>
           ${sectionCheck && !sectionCheck.ok ? `<div class="flex items-center gap-3 px-3 py-2.5 bg-red-50 dark:bg-red-900/20 border border-red-300 dark:border-red-700 rounded-xl"><i data-lucide="triangle-alert" class="w-5 h-5 text-red-500 shrink-0"></i><div><p class="text-[11px] font-black text-red-600 dark:text-red-400 uppercase tracking-wide">Secci\u00f3n incompatible</p><p class="text-[10px] text-red-500 dark:text-red-400 leading-snug">El terminal <strong>${termOrig}</strong> no admite <strong>${c.seccion} mm\u00b2</strong>. V\u00e1lidas: <strong>${sectionCheck.validSections.join(', ')} mm\u00b2</strong></p></div></div>` : ''}
          ${m && m !== "S/M" ? `
                    <div class="mt-2 flex flex-col w-full">
                        <div class="p-3 bg-sap-bg dark:bg-slate-900 rounded-xl flex items-center gap-3 mb-2 border border-slate-200 dark:border-slate-700 shadow-sm">
                            <div class="w-12 h-10 flex items-center justify-center shrink-0 bg-white rounded border border-slate-200 dark:border-slate-500 overflow-hidden p-0.5">
                                <img src="manguitos/${m.trim()}.jpg" class="max-h-full max-w-full object-contain" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                <i data-lucide="layers" class="w-5 h-5 text-sap-blue" style="display: none;"></i>
                            </div>
                            <div class="min-w-0 flex-1">
                                <p class="text-[9px] font-bold uppercase opacity-60">Manguito</p>
                                <p class="text-base font-black truncate">${m}</p>
                                <p class="text-[10px] text-sap-blue italic truncate">${masterMap.sleeves[m?.trim()] || 'Sin descripción técnica'}</p>
                            </div>
                        </div>
                        
                       <div class="flex flex-col gap-1 w-full">
                <div class="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-0.5 ml-1">Marcaje Físico</div>
                <div class="flex items-stretch border ${getManguitoBgClass(m)} rounded-r-lg shadow-sm overflow-hidden font-mono text-[11px] text-black">
                 <div class="flex-1 flex">
    <div class="w-1/2 border-r border-black/20 py-1 px-2 flex flex-col items-center justify-center text-center font-bold">
        <span>${c.cable_marca || ''}</span>
    </div>
    <div class="w-1/2 py-1 px-2 flex flex-col items-center justify-center text-center font-bold leading-tight">
        <span class="truncate w-full">${c.de_elemento || ''} ${c.de_punto || ''}</span>
        <span class="truncate w-full">${c.para_elemento || ''} ${c.para_punto || ''}</span>
    </div>
</div>

                  <div class="w-1.5 ${getHoleRightClass(m)} shadow-inner flex-shrink-0"></div>
                </div>
              </div>
              ${obs ? `<div class="flex flex-col gap-1 w-full mt-1"><div class="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-0.5 ml-1">Observaciones</div><div class="px-2 py-1.5 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/40 rounded text-[10px] text-amber-700 dark:text-amber-400 font-medium italic leading-snug">${obs}</div></div>` : ''}
                    </div>
                    ` : ''}
          ${obs && !(m && m !== "S/M") ? `<div class="flex flex-col gap-1 w-full mt-1"><div class="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-0.5 ml-1">Observaciones</div><div class="px-2 py-1.5 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/40 rounded text-[10px] text-amber-700 dark:text-amber-400 font-medium italic leading-snug">${obs}</div></div>` : ''}
           <label class="flex items-center justify-center gap-3 w-full rounded-xl cursor-pointer select-none border-2 transition-all mt-1 ${isCurrentSideOk ? 'bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400' : 'bg-sap-shell/5 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400'}" style="min-height:52px;">
               <input type="checkbox" ${isCurrentSideOk ? 'checked' : ''} 
                   onchange="toggleProgress('${c.posicion}', '${currentElName}')" 
                   class="sr-only">
               <i data-lucide="${isCurrentSideOk ? 'check-circle-2' : 'circle'}" class="w-5 h-5 shrink-0"></i>
               <span class="text-sm font-bold uppercase tracking-wide">${isCurrentSideOk ? 'Conexión realizada' : 'Marcar como hecho'}</span>
           </label>
`; 
   }).join(''); 
   lucide.createIcons(); 
}
        
       function renderProgressList() {
   const list = document.getElementById('detailProgressList');
   if (!list) return;
 
   const currentElName = document.getElementById('detailElementName').innerText.toLowerCase();
   
   list.innerHTML = detailPinSequence.map((pin, i) => { 
       const connections = detailPinDataMap.get(pin) || [];
       
       // EVALUACIÓN LOCAL ASIMÉTRICA: El punto está listo si todos los cables 
       // de este pin están validados en el extremo de este elemento actual.
       const isAllDone = connections.length > 0 && connections.every(c => {
           const prog = progressMap[c.posicion];
           if (!prog) return false;
 
           const row = rawData.find(r => r.posicion === c.posicion);
           if (!row) return false;
 
           if ((row.de_elemento || '').toLowerCase() === currentElName) {
               return prog.de === true;
           } else if ((row.para_elemento || '').toLowerCase() === currentElName) {
               return prog.para === true;
           }
           return false;
       });
       
       return `<button onclick="goToDetailStep(${i})" class="w-full flex items-center justify-center p-3 rounded-lg border text-center transition-all ${i === currentDetailIndex ? 'bg-sap-blue text-white shadow-lg scale-105' : (isAllDone ? 'bg-emerald-50 dark:bg-emerald-900/10 border-emerald-200' : 'bg-white dark:bg-slate-800 border-sap-border')}">
           <div class="flex flex-col items-center gap-1 min-w-0">
               <span class="font-black text-sm truncate uppercase tracking-tighter">${pin}</span>
               <i id="tick-${i}" data-lucide="check-circle-2" class="w-3 h-3 text-[#10b981] ${isAllDone ? '' : 'hidden'}"></i>
           </div>
       </button>`; 
   }).join(''); 
   
   if (window.lucide) lucide.createIcons();
}
function nextDetailStep() {
   const p = detailPinSequence[currentDetailIndex];
   const cs = detailPinDataMap.get(p) || [];
   const currentElName = document.getElementById('detailElementName').innerText.toLowerCase();
   
   // Al pulsar Siguiente, aseguramos que el extremo de este elemento quede marcado como OK
   cs.forEach(c => {
       if (!progressMap[c.posicion]) progressMap[c.posicion] = { de: false, para: false };
       
       const row = rawData.find(r => r.posicion === c.posicion);
       if (row) {
           if ((row.de_elemento || '').toLowerCase() === currentElName) progressMap[c.posicion].de = true;
           if ((row.para_elemento || '').toLowerCase() === currentElName) progressMap[c.posicion].para = true;
       }
   });
   
   saveProgress();
   registerChange();
   updateGlobalProgress();
   
   // Control secuencial de pasos del asistente Modo Visión
   if (currentDetailIndex < detailPinSequence.length - 1) {
       currentDetailIndex++;
       renderDetailStep();     // Carga el layout del siguiente pin
       renderProgressList();   // Ilumina el tick verde del paso que acabamos de completar
   } else {
       closeDetailMode();      // Si es el último paso del componente, salimos de forma limpia
   }
}
       function prevDetailStep() { if (currentDetailIndex > 0) { currentDetailIndex--; renderDetailStep(); renderProgressList(); } }
       function goToDetailStep(idx) { currentDetailIndex = idx; renderDetailStep(); renderProgressList(); }
 
       function updateMetadataUI() { document.getElementById('meta-equipo').innerText = reportMetadata.equipo || '---'; document.getElementById('meta-desc').innerText = reportMetadata.desc || '---'; document.getElementById('meta-lista').innerText = reportMetadata.lista || '---'; document.getElementById('meta-edicion').innerText = reportMetadata.edicion || '---'; document.getElementById('meta-fecha').innerText = reportMetadata.fecha || '---'; document.getElementById('meta-plano').innerText = reportMetadata.plano || '---'; }
    function clearAllFilters() { document.getElementById('filterInput').value = ''; document.getElementById('filterMarcaInput').value = ''; document.getElementById('globalSearchInput').value = ''; filterText = ''; filterMarcaText = ''; filterTerminalError = null; selectedMaterial = null; currentMatchIdx = -1; document.getElementById('searchCounter').innerText = ''; document.getElementById('elementQuickActions').classList.add('hidden'); updateView(); }
       function toggleTerminalErrorFilter(key) {
           filterTerminalError = (filterTerminalError === key) ? null : key;
           renderTable();
           lucide.createIcons();
       }

       function applyTableFilter(v) { 
   filterText = v; 
   selectedMaterial = null; 
   document.getElementById('filterInput').value = v;
   const qa = document.getElementById('elementQuickActions');
   const isSingle = !!v.trim() && !v.includes('+');
   qa.classList.toggle('hidden', !isSingle);
   qa.classList.toggle('flex', !!isSingle);
   updateView(); 
}
function selectMaterial(name) {
    // Si pulsamos el mismo material, deseleccionamos. Si es distinto, lo asignamos.
    selectedMaterial = (selectedMaterial === name) ? null : name;
    // Forzamos el repintado de la tabla para aplicar las clases de color 'isSelected'
    renderTable();
}
        function _checkDuplicateColumns(data) {
            _dupPosicions.clear(); _dupOrdenes.clear(); _nonNumericLongitud.clear();
            _seccionMissingSet.clear(); _termIncompatSet.clear(); _termNotFoundSet.clear();
            _cableNotFoundSet.clear(); _sleeveNotFoundSet.clear();
            const getDuplicates = field => {
                const counts = {};
                data.forEach(r => { const v = (r[field]||'').toString().trim(); if (v) counts[v] = (counts[v]||0)+1; });
                return Object.keys(counts).filter(v => counts[v] > 1);
            };
            const dupA = getDuplicates('posicion'), dupB = getDuplicates('orden');
            dupA.forEach(v => _dupPosicions.add(v));
            dupB.forEach(v => _dupOrdenes.add(v));

            // Sección faltante con terminal asignado
            const _tv = t => !!(t && t !== 'S/T' && t !== 'S/M' && !isKN(t));
            const secMissingPos = data
                .filter(r => !r.seccion && (_tv(r.de_terminal) || _tv(r.para_terminal)))
                .map(r => r.posicion).filter(Boolean);

            // Longitud con caracteres no numéricos en col. E
            data.filter(r => { const v = (r.longitud||'').toString().trim(); return v !== '' && !/^[\d.,]+$/.test(v); })
                .forEach(r => { if (r.posicion) _nonNumericLongitud.add((r.posicion).toString().trim()); });

            // Terminal incompatible con la sección
            const termIncompatPos = data
                .filter(r => {
                    const chk = key => { const v = r[key]||''; if (!v || v==='S/T' || isKN(v) || !r.seccion) return false; const sc = checkSectionCompatibility(v, r.seccion); return sc && !sc.ok; };
                    return chk('de_terminal') || chk('para_terminal');
                })
                .map(r => r.posicion).filter(Boolean);

            // Terminal / pin no dado de alta en master-data.js (columnas J y O)
            const termNotFoundPos = data
                .filter(r => {
                    const chk = key => { const v = r[key]||''; if (!v || isKN(v)) return false; return !isValidTerminalCode(v); };
                    return chk('de_terminal') || chk('para_terminal');
                })
                .map(r => r.posicion).filter(Boolean);

            const cableNotFoundPos = data
                .filter(r => r.cod_cable && !isValidCableCode(r.cod_cable))
                .map(r => r.posicion).filter(Boolean);
            const sleeveNotFoundPos = data
                .filter(r => r.de_manguito && !isValidSleeveCode(r.de_manguito))
                .map(r => r.posicion).filter(Boolean);

            secMissingPos.forEach(v => _seccionMissingSet.add(v.toString().trim()));
            termIncompatPos.forEach(v => _termIncompatSet.add(v.toString().trim()));
            termNotFoundPos.forEach(v => _termNotFoundSet.add(v.toString().trim()));
            cableNotFoundPos.forEach(v => _cableNotFoundSet.add(v.toString().trim()));
            sleeveNotFoundPos.forEach(v => _sleeveNotFoundSet.add(v.toString().trim()));
            updateEstadoUI();

            if (!dupA.length && !dupB.length && !secMissingPos.length && !termIncompatPos.length && !_nonNumericLongitud.size && !termNotFoundPos.length && !cableNotFoundPos.length && !sleeveNotFoundPos.length) return;

            const _listPos = (arr, max = 10) => arr.length <= max ? arr.join(', ') : arr.slice(0, max).join(', ') + ` y ${arr.length - max} más...`;

            let msg = '⚠ Se han detectado incidencias en el fichero Excel:\n';
            if (dupA.length)          msg += `\n● Posiciones duplicadas (col. A): ${dupA.join(', ')}`;
            if (dupB.length)          msg += `\n● Órdenes duplicadas (col. B): ${dupB.join(', ')}`;
            if (secMissingPos.length) msg += `\n● Sección sin definir con terminal asignado (${secMissingPos.length}): pos. ${_listPos(secMissingPos)}`;
            if (termIncompatPos.length) msg += `\n● Terminal incompatible con la sección (${termIncompatPos.length}): pos. ${_listPos(termIncompatPos)}`;
            if (_nonNumericLongitud.size) msg += `\n● Longitud con valor no numérico (col. E) (${_nonNumericLongitud.size}): pos. ${_listPos([..._nonNumericLongitud])}`;
            if (termNotFoundPos.length) msg += `\n● El terminal / pin no existe o no está dado de alta en la base de datos (${termNotFoundPos.length}): pos. ${_listPos(termNotFoundPos)}`;
            if (cableNotFoundPos.length) msg += `\n● ID CABLE no existe o no está dado de alta en la base de datos (${cableNotFoundPos.length}): pos. ${_listPos(cableNotFoundPos)}`;
            if (sleeveNotFoundPos.length) msg += `\n● DE MANGUITO no existe o no está dado de alta en la base de datos (${sleeveNotFoundPos.length}): pos. ${_listPos(sleeveNotFoundPos)}`;
            msg += '\n\nRevisa el fichero antes de continuar.';
            setTimeout(() => showFileIssuesModal(msg), 200);
        }

        function showFileIssuesModal(message) {
            const modal = document.getElementById('fileIssuesModal');
            const messageElement = document.getElementById('fileIssuesMessage');
            if (!modal || !messageElement) return;
            const escapeHtml = value => value.replace(/[&<>"']/g, character => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
            }[character]));
            const getErrorClass = line => {
                if (line.includes('Posiciones duplicadas') || line.includes('Órdenes duplicadas')) return 'estado-dot-orange';
                if (line.includes('Sección sin definir')) return 'estado-dot-yellow';
                if (line.includes('Terminal incompatible')) return 'estado-dot-red';
                if (line.includes('Longitud con valor no numérico')) return 'estado-dot-purple';
                if (line.includes('terminal / pin no existe')) return 'estado-dot-pink';
                if (line.includes('ID CABLE no existe')) return 'estado-dot-emerald';
                if (line.includes('DE MANGUITO no existe')) return 'estado-dot-brown';
                return null;
            };
            messageElement.innerHTML = message.split('\n').map(line => {
                const errorClass = getErrorClass(line);
                if (!errorClass) return `<div>${escapeHtml(line) || '&nbsp;'}</div>`;
                return `<div class="flex items-start gap-2"><span class="w-2 h-2 rounded-full ${errorClass} mt-1.5 shrink-0"></span><span>${escapeHtml(line.replace(/^\s*●\s*/, ''))}</span></div>`;
            }).join('');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
            if (window.lucide) lucide.createIcons();
        }

        function closeFileIssuesModal() {
            const modal = document.getElementById('fileIssuesModal');
            if (!modal) return;
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }

        function updateEstadoUI() {
            const container = document.getElementById('estado-circles');
            if (!container) return;
            const hasData = rawData && rawData.length > 0;
            if (!hasData) {
                container.innerHTML = `<span class="w-3 h-3 rounded-full bg-slate-400 dark:bg-slate-600 inline-block" title="Sin datos cargados"></span>`;
                return;
            }
            const errores = [];
            if (_dupPosicions.size > 0)      errores.push({ css: 'estado-dot-orange', txt: `Posiciones duplicadas: ${_dupPosicions.size} afectadas` });
            if (_dupOrdenes.size > 0)         errores.push({ css: 'estado-dot-orange', txt: `Órdenes duplicadas: ${_dupOrdenes.size} afectadas` });
            if (_seccionMissingSet.size > 0)  errores.push({ css: 'estado-dot-yellow', txt: `Sección sin definir con terminal asignado: ${_seccionMissingSet.size} líneas` });
            if (_termIncompatSet.size > 0)    errores.push({ css: 'estado-dot-red',    txt: `Terminal incompatible con la sección: ${_termIncompatSet.size} líneas` });
            if (_nonNumericLongitud.size > 0) errores.push({ css: 'estado-dot-purple', txt: `Longitud con valor no numérico: ${_nonNumericLongitud.size} líneas` });
            if (_termNotFoundSet.size > 0)    errores.push({ css: 'estado-dot-pink',   txt: `Terminal / pin no existe en master-data.js: ${_termNotFoundSet.size} líneas` });
            if (_cableNotFoundSet.size > 0)    errores.push({ css: 'estado-dot-emerald', txt: `ID CABLE no existe en master-data.js: ${_cableNotFoundSet.size} líneas` });
            if (_sleeveNotFoundSet.size > 0)   errores.push({ css: 'estado-dot-brown',  txt: `DE MANGUITO no existe en master-data.js: ${_sleeveNotFoundSet.size} líneas` });
            if (errores.length === 0) {
                container.innerHTML = `<span class="w-3 h-3 rounded-full bg-green-500 inline-block flex-shrink-0" title="Sin errores detectados"></span>
                    <span class="text-[9px] text-green-600 dark:text-green-400 font-semibold">Correcto</span>`;
            } else {
                container.innerHTML = errores.map(e =>
                    `<span class="w-3 h-3 rounded-full inline-block flex-shrink-0 ${e.css} cursor-help" title="${e.txt}" ontouchstart="showEstadoErrorTip(this, '${e.css}', '${e.txt}'); event.stopPropagation()"></span>`
                ).join('');
            }
        }

        function showEstadoErrorTip(element, errorClass, message) {
            const schemes = {
                'estado-dot-orange': 'orange',
                'estado-dot-yellow': 'amber',
                'estado-dot-red': 'red',
                'estado-dot-purple': 'purple',
                'estado-dot-pink': 'pink',
                'estado-dot-emerald': 'emerald',
                'estado-dot-brown': 'brown'
            };
            showCellErrorTip(element, schemes[errorClass] || 'red', 'ESTADO', `<p>${message}</p>`);
        }

         function handleFileUpload(event) {
           const f = event.target.files[0]; if (!f) return;
           const reader = new FileReader();
           reader.onload = (e) => {
               const d = new Uint8Array(e.target.result), wb = XLSX.read(d, { type: 'array' }), sh = wb.Sheets[wb.SheetNames[0]];
               // header:'A' + defval:'' → objetos con clave = letra de columna Excel (A,B,C...)
               // defval:'' garantiza que las celdas vacías tengan '' en lugar de undefined
               const json = XLSX.utils.sheet_to_json(sh, { header: 'A', defval: '' });
               const gc  = (ri, col) => { const r = json[ri]; return r ? (r[col] ?? '') : ''; };
               const _sv = v => (v != null ? String(v) : '');
               const parseDate = (val) => { if (!val) return ''; let date = (typeof val === 'number') ? new Date((val - 25569) * 86400 * 1000) : new Date(val); return isNaN(date.getTime()) ? val.toString() : `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`; };
               // Detectar inicio de datos: primera fila cuya col. A sea número puro (001..n)
               const _isNumPos = v => !!v && /^\d+$/.test(String(v).trim());
               const _firstDataIdx = json.findIndex(row => _isNumPos(row['A']));
               const _multiHdr = _firstDataIdx >= 3; // encabezado de más de una fila
               if (_multiHdr) {
                   // Mapeo encabezado multi-fila: EQUIPO=D3, DESC=D2, PLANO=D5, LISTA=J4, EDICIÓN=J2, FECHA=P2
                   reportMetadata = { equipo: _sv(gc(2,'D')), desc: _sv(gc(1,'D')), plano: _sv(gc(4,'D')), lista: _sv(gc(3,'J')), edicion: _sv(gc(1,'J')), fecha: parseDate(gc(1,'P')) };
               } else {
                   // Mapeo encabezado simple: fila 1 columnas Q-V
                   reportMetadata = { equipo: _sv(gc(1,'Q')), desc: _sv(gc(1,'R')), plano: _sv(gc(1,'S')), lista: _sv(gc(1,'T')), edicion: _sv(gc(1,'U')), fecha: parseDate(gc(1,'V')) };
               }
               // Mapeo de datos (igual en ambos formatos): A=posicion B=orden C=cod_cable D=seccion
               // E=longitud F=marcado G=cable_marca H=de_elemento I=de_punto J=de_terminal
               // K=de_manguito L=para_manguito M=para_elemento N=para_punto O=para_terminal P=observaciones
               rawData = json.map(row => ({
                   posicion:       _sv(row['A']), orden:          _sv(row['B']),
                   cod_cable:      _sv(row['C']), seccion:        _sv(row['D']),
                   longitud:       _sv(row['E']), marcado:        _sv(row['F']),
                   cable_marca:    _sv(row['G']), de_elemento:    _sv(row['H']),
                   de_punto:       _sv(row['I']), de_terminal:    _sv(row['J']),
                   de_manguito:    _sv(row['K']), para_manguito:  _sv(row['L']),
                   para_elemento:  _sv(row['M']), para_punto:     _sv(row['N']),
                   para_terminal:  _sv(row['O']), observaciones:  _sv(row['P']),
                   desc_cable:         _sv(row['X']), desc_manguito:      _sv(row['Y']),
                   desc_terminal_de:   _sv(row['Z']), desc_terminal_para: _sv(row['AA'])
               })).filter(r => {
                   if (!_isNumPos(r.posicion)) return false;
                   // Descartar filas donde solo A y/o B tienen dato y el resto (C-P) están vacías
                   const DATA_KEYS = ['cod_cable','seccion','longitud','marcado','cable_marca',
                       'de_elemento','de_punto','de_terminal','de_manguito','para_manguito',
                       'para_elemento','para_punto','para_terminal','observaciones'];
                   return DATA_KEYS.some(k => (r[k]||'').trim() !== '');
               });
               rawData.forEach(r => { if (r.cod_cable && r.desc_cable) masterMap.cables[r.cod_cable.toString().trim()] = r.desc_cable; if (r.de_terminal && r.desc_terminal_de) masterMap.terminals[r.de_terminal.toString().trim()] = r.desc_terminal_de; if (r.para_terminal && r.desc_terminal_para) masterMap.terminals[r.para_terminal.toString().trim()] = r.desc_terminal_para; if (r.de_manguito && r.desc_manguito) masterMap.sleeves[r.de_manguito.toString().trim()] = r.desc_manguito; if (r.para_manguito && r.desc_manguito) masterMap.sleeves[r.para_manguito.toString().trim()] = r.desc_manguito; });
 loadProgress(); loadErrors(); hasUnsavedChanges = false; updateSaveButton(); updateGlobalProgress(); updateErrorBadge(); document.getElementById('landingPage').classList.add('hidden'); updateMetadataUI(); _checkDuplicateColumns(rawData); currentView = 'table'; clearAllFilters();
           }; reader.readAsArrayBuffer(f);
       }
       function handleBreakerClick(event) { if (event) event.stopPropagation(); const b = document.getElementById('landingBreaker'), e = document.getElementById('landingEye'); b.classList.add('is-on'); if (e) e.classList.add('eye-on'); setTimeout(() => { const input = document.getElementById('csvInputLanding'); if (input) input.click(); }, 400); }
 
       function renderSummary() {
           const grid = document.getElementById('summaryGrid'), tableC = document.getElementById('summaryTableContainer'), tableB = document.getElementById('summaryTableBody'), title = document.getElementById('summaryTitle'); 
           if(!grid || !title || !tableC) return;
           grid.innerHTML = ''; tableB.innerHTML = ''; let stats = {}; 
           const exportGroup = document.getElementById('sleeveExportGroup');
           exportGroup.classList.toggle('hidden', currentView !== 'summary-sleeves');
 
           if (currentView === 'summary-cables') { 
               title.innerText = i18n[currentLang].cableSum; rawData.forEach(r => { if(r.cod_cable && r.cod_cable.trim()) { const c = r.cod_cable.trim(); if(!stats[c]) stats[c]={count:0,length:0,desc:masterMap.cables[c]||""}; stats[c].count++; stats[c].length+=parseFloat((r.longitud||"0").toString().replace(',','.'))||0; } }); 
           } else if (currentView === 'summary-terminals') { 
               title.innerText = i18n[currentLang].termList; rawData.forEach(r => { [r.de_terminal, r.para_terminal].forEach(t => { if (t && t.toUpperCase()!=='S/T' && !isKN(t)) { const c = t.trim(); if(!stats[c]) stats[c]={count:0,desc:masterMap.terminals[c]||""}; stats[c].count++; } }); }); 
           } else { 
               title.innerText = i18n[currentLang].sleeveList; rawData.forEach(r => { if(r.de_manguito && r.de_manguito.toUpperCase()!=='S/M') { const c = r.de_manguito.trim(); if(!stats[c]) stats[c]={count:0,desc:masterMap.sleeves[c]||""}; stats[c].count++; } }); 
           }
           currentSummaryStats = stats; const entries = Object.entries(stats).sort((a, b) => a[0].localeCompare(b[0], undefined, {numeric: true}));
           if (!entries.length) { grid.innerHTML = `<p class="col-span-full py-12 text-center text-sap-secondaryText">${i18n[currentLang].noItems}</p>`; return; }
           document.getElementById('btnSummaryCards').classList.toggle('text-sap-blue', summaryViewMode === 'cards');
           document.getElementById('btnSummaryTable').classList.toggle('text-sap-blue', summaryViewMode === 'table');
           if (summaryViewMode === 'cards') {
               grid.classList.remove('hidden'); tableC.classList.add('hidden');
               grid.innerHTML = entries.map(([ref, val]) => `<div class="bg-blue-50/20 dark:bg-slate-800/50 p-4 rounded-sm border-t-4 border-t-sap-blue border-l-4 border-l-sap-blue/20 border-r border-b border-sap-border dark:border-slate-700 shadow-sm group hover:shadow-lg transition-all text-left"><div class="text-[9px] font-black text-sap-secondaryText uppercase mb-1 tracking-wider">${ref}</div><div class="text-xs font-bold mb-4 h-8 overflow-hidden leading-snug">${val.desc || '---'}</div><div class="flex justify-between items-end"><div><div class="text-[9px] uppercase font-black text-sap-blue/60">${currentView === 'summary-cables' ? 'Cortes' : 'Cantidad'}</div><div class="text-2xl font-black tabular-nums">${val.count}</div></div>${val.length?`<div><div class="text-[9px] uppercase font-black text-sap-blue/60">Cantidad</div><div class="text-lg font-black text-sap-blue">${val.length.toFixed(2)}m</div></div>`:''}</div></div>`).join('');
           } else {
               grid.classList.add('hidden'); tableC.classList.remove('hidden');
               tableB.innerHTML = entries.map(([ref, val]) => `<tr class="border-b border-sap-border dark:border-slate-700 hover:bg-sap-blue/5 transition-colors"><td class="p-3 text-xs font-bold text-sap-blue">${ref}</td><td class="p-3 text-xs">${val.desc || '---'}</td><td class="p-3 text-sm font-black text-center tabular-nums">${val.count}</td></tr>`).join('');
           }
       }
 
       function setSummaryMode(mode) { summaryViewMode = mode; renderSummary(); lucide.createIcons(); }
        function sortTable(key) {
   if (currentSortCol === key) {
       sortAsc = !sortAsc;
   } else {
       currentSortCol = key;
       sortAsc = true;
   }
   renderTable();
}
       function changeView(v) { currentView = v; updateView(); }
    
       function adjustZoom(f) { currentZoom = Math.min(Math.max(currentZoom * f, 0.2), 5); updateViewBox(); }
      function fitDiagramToScreen() {
           const container = document.getElementById('diagramContainer');
           if (!container || !baseViewBox.w || !baseViewBox.h) return;
           const padding = 20;
           const availW = container.clientWidth  - padding * 2;
           const availH = container.clientHeight - padding * 2;
           if (availW <= 0 || availH <= 0) return;
           const fitZoom = Math.min(availW / baseViewBox.w, availH / baseViewBox.h);
           currentZoom = fitZoom > 1 ? 1 : fitZoom;
           panX = 0; panY = 0;
           updateViewBox();
       }
       function resetZoomAndPan() { fitDiagramToScreen(); }
       function updateViewBox() { const s = document.getElementById('diagramSvg'); if (!s || !baseViewBox.w) return; const w = baseViewBox.w / currentZoom, h = baseViewBox.h / currentZoom, x = (baseViewBox.w - w)/2 - (panX/currentZoom), y = (baseViewBox.h - h)/2 - (panY/currentZoom); s.setAttribute('viewBox', `${x} ${y} ${w} ${h}`); }
       function hidePinPopover() { const p = document.getElementById('pinPopover'); if (!p) return; p.classList.remove('show'); setTimeout(() => { if (!p.classList.contains('show')) p.classList.add('hidden'); }, 300); }
       
       function showInfoPopover(e, s) {
   e.stopPropagation();
   const d = JSON.parse(decodeURIComponent(s)),
       p = document.getElementById('pinPopover'),
       c = document.getElementById('popoverContent'),
       h = document.getElementById('popoverPinName');
   
   if (!p || !c || !h) return;
   let html = '';
 
   if (d.type === 'pin') {
       h.innerText = `Punto de Conexión: ${d.pin}`;
       _lastPinPopoverArgs = s;
       const currentEl = document.getElementById('graphElementName')?.innerText?.toLowerCase() || '';
       d.connections.forEach((cn, idx) => {
           const tDesc = masterMap.terminals[cn.term?.trim()] || "",
               sDesc = masterMap.sleeves[cn.sleeve?.trim()] || "",
               isPseudoTerminal = isKN(cn.term);
 
           // Buscamos los datos del cable por posición (identificador único) para evitar
           // confusión cuando varios cables comparten el mismo nombre/marca.
           const cableData = (cn.posicion ? rawData.find(wire => wire.posicion === cn.posicion) : null)
               || rawData.find(wire => wire.cable_marca === cn.label);
           const section = cableData ? cableData.seccion : "";
           const crimpData = getCrimpingInfo(cn.term, section);
           const sectionCheck = !isPseudoTerminal ? checkSectionCompatibility(cn.term, section) : null;
           const prog = progressMap[cn.posicion] || { de: false, para: false };
           let isDone = false;
           if (cableData) {
               if ((cableData.de_elemento || '').toLowerCase() === currentEl) isDone = prog.de === true;
               else if ((cableData.para_elemento || '').toLowerCase() === currentEl) isDone = prog.para === true;
           }
 
           html += `<div class="${idx > 0 ? 'mt-4 pt-3 border-t-2 border-slate-200 dark:border-slate-600' : ''}">
                <div class="flex items-center justify-between mb-2">
                    <span class="bg-sap-blue text-white px-2 py-0.5 rounded text-[9px] font-black uppercase cursor-pointer" onclick="showInfoPopover(event, '${encodeURIComponent(JSON.stringify({type:'cable', label: cn.label}))}')">Cable: ${cn.label}</span>
                    <div class="flex items-center gap-1">
                        ${crimpData ? `<button onclick="openCrimpingModal('${cn.term}', '${section}')" class="p-1 bg-sap-blue text-white rounded hover:bg-sap-darkBlue transition-colors"><i data-lucide="wrench" class="w-3 h-3"></i></button>` : ''}
                    </div>
                </div>
                <div class="space-y-3">
                    <div class="bg-slate-50 dark:bg-slate-800/60 p-2 rounded border border-slate-200 dark:border-slate-600">
                        <div class="flex items-center gap-2 text-sap-blue dark:text-sky-400 mb-1">
                            <div class="w-12 h-8 flex items-center justify-center bg-white dark:bg-slate-700 rounded border border-slate-200 dark:border-slate-500 overflow-hidden shrink-0">
                                ${!isPseudoTerminal && cn.term ? 
                                    `<img src="${CRIMP_PATHS.terminales}${cn.term.trim()}.jpg" class="max-h-full max-w-full object-contain" onerror="handlePinError(this)">`
                                    : (isPseudoTerminal ? '' : `<i data-lucide="pin" class="w-3.5 h-3.5"></i>`)
                                }
                            </div>
                            <span class="font-bold uppercase tracking-tighter text-[10px]">${isPseudoTerminal ? 'Instrucción' : 'Terminal'}</span>
                        </div>
                        <div class="${!isPseudoTerminal ? 'pl-14' : ''}">
                            <div class="font-black text-xs text-slate-800 dark:text-slate-100">${isPseudoTerminal ? cn.term.substring(3) : cn.term || 'S/T'}</div>
                            <div class="text-[10px] text-slate-500 dark:text-slate-400 italic leading-tight">${tDesc}</div>
                        </div>
                    </div>
                    ${sectionCheck && !sectionCheck.ok ? `<div class="flex items-center gap-2 px-2 py-1.5 bg-red-50 dark:bg-red-900/20 border border-red-300 dark:border-red-700 rounded text-[10px]"><i data-lucide="triangle-alert" class="w-3.5 h-3.5 text-red-500 shrink-0"></i><span class="text-red-600 dark:text-red-400"><strong>${cn.term}</strong> no admite <strong>${section} mm\u00b2</strong>. V\u00e1lidas: <strong>${sectionCheck.validSections.join(', ')} mm\u00b2</strong></span></div>` : ''}

                    ${cn.sleeve && cn.sleeve !== 'S/M' ? `
                    <div class="mt-2 flex flex-col gap-2 w-full">
                        <div class="bg-slate-50 dark:bg-slate-800/60 p-2 rounded border border-slate-200 dark:border-slate-600">
                            <div class="flex items-center gap-2 text-sap-blue dark:text-sky-400 mb-1">
                                <div class="w-12 h-8 flex items-center justify-center bg-white dark:bg-slate-700 rounded border border-slate-200 dark:border-slate-500 overflow-hidden shrink-0 p-0.5">
                                    <img src="Manguitos/${cn.sleeve.trim()}.jpg" class="max-h-full max-w-full object-contain" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                                    <i data-lucide="layers" class="w-3.5 h-3.5" style="display: none;"></i>
                                </div>
                                <span class="font-bold uppercase tracking-tighter text-[10px]">Manguito</span>
                            </div>
                            <div class="pl-14">
                                <div class="font-black text-xs text-slate-800 dark:text-slate-100">${cn.sleeve}</div>
                                <div class="text-[10px] text-slate-500 dark:text-slate-400 italic leading-tight">${sDesc || 'Sin descripción técnica'}</div>
                            </div>
                        </div>
                        
                        <div class="flex flex-col gap-1 w-full">
                                <div class="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-0.5 ml-1">Marcaje Físico</div>
                                <div class="flex items-stretch border ${getManguitoBgClass(cn.sleeve)} rounded-r-lg shadow-sm overflow-hidden font-mono text-[11px] text-black">
                                 <div class="flex-1 flex">
    <div class="w-1/2 border-r border-black/20 py-1 px-2 flex flex-col items-center justify-center text-center font-bold">
        <span>${cn.label || ''}</span>
    </div>
    <div class="w-1/2 py-1 px-2 flex flex-col items-center justify-center text-center font-bold leading-tight">
        <span class="truncate w-full">${cableData ? (cableData.de_elemento || '') + ' ' + (cableData.de_punto || '') : ''}</span>
        <span class="truncate w-full">${cableData ? (cableData.para_elemento || '') + ' ' + (cableData.para_punto || '') : ''}</span>
    </div>
</div>

                                    <div class="w-1.5 ${getHoleRightClass(cn.sleeve)} shadow-inner flex-shrink-0"></div>
                                </div>
                            </div>
                            ${cn.observaciones ? `<div class="flex flex-col gap-1 w-full mt-1"><div class="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-0.5 ml-1">Observaciones</div><div class="px-2 py-1.5 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/40 rounded text-[10px] text-amber-700 dark:text-amber-400 font-medium italic leading-snug">${cn.observaciones}</div></div>` : ''}
                    </div>
                    ` : ''}
                ${cn.observaciones && !(cn.sleeve && cn.sleeve !== 'S/M') ? `<div class="flex flex-col gap-1 w-full mt-2"><div class="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-0.5 ml-1">Observaciones</div><div class="px-2 py-1.5 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/40 rounded text-[10px] text-amber-700 dark:text-amber-400 font-medium italic leading-snug">${cn.observaciones}</div></div>` : ''}
                ${cn.posicion ? `<button onclick="markConnectionDone('${cn.posicion}')" class="mt-3 flex items-center justify-center gap-2 w-full rounded-xl border-2 font-bold uppercase tracking-wide text-sm transition-all ${isDone ? 'bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400' : 'bg-slate-100 dark:bg-slate-800 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400'}" style="min-height:48px;" title="${isDone ? 'Marcar como pendiente' : 'Marcar como realizado'}"><i data-lucide="${isDone ? 'check-circle-2' : 'circle'}" class="w-5 h-5 shrink-0"></i>${isDone ? 'Conexión realizada' : 'Marcar como hecho'}</button>` : ''}
                </div>
            </div>`;
       });
  } else if (d.type === 'cable') {
       const cd = d.posicion
           ? rawData.find(r => r.posicion === d.posicion)
           : rawData.find(r => r.cable_marca === d.label);
       const allCd = cd ? [cd] : [];
       h.innerText = `Detalle de Cable: ${d.label}`;
       const longitudesHtml = allCd.map(r => `
           <div class="flex justify-between items-center py-1 border-b border-amber-200 dark:border-amber-700/50 last:border-0">
               <span class="text-[10px] text-amber-700 dark:text-amber-400 truncate max-w-[60%]">${(r.de_elemento || '---').toUpperCase()} → ${(r.para_elemento || '---').toUpperCase()}</span>
               <span class="text-sm font-black text-amber-600 dark:text-amber-300 ml-2">${r.longitud || '0'} m</span>
           </div>`).join('');
       html = `<div class="space-y-3">
           <div class="bg-slate-50 dark:bg-slate-800/60 p-3 rounded border border-slate-200 dark:border-slate-600">
               <p class="text-[9px] font-bold uppercase text-slate-500 dark:text-slate-400">Código ID</p>
               <p class="text-sm font-black text-sap-blue dark:text-sky-400">${cd?.cod_cable || '---'}</p>
           </div>
           <div class="bg-slate-50 dark:bg-slate-800/60 p-3 rounded border border-slate-200 dark:border-slate-600">
               <p class="text-[9px] font-bold uppercase text-slate-500 dark:text-slate-400">Descripción</p>
               <p class="text-xs font-bold leading-tight text-slate-800 dark:text-slate-100">${masterMap.cables[cd?.cod_cable?.toString()?.trim()] || "Sin descripción técnica"}</p>
           </div>
           <div class="bg-amber-50 dark:bg-amber-900/30 p-3 rounded border border-amber-200 dark:border-amber-700">
               <p class="text-[9px] font-bold uppercase text-amber-600 dark:text-amber-400 mb-2">Longitud${allCd.length > 1 ? ' por tramo' : ''}</p>
               ${longitudesHtml}
           </div>
       </div>`;
   }
 
   c.innerHTML = html;
   p.style.left = `24px`;
   p.style.top = `24px`;
   p.classList.remove('hidden');
   void p.offsetWidth;
   p.classList.add('show');
   lucide.createIcons();
}
 
  // 1. Panel de Materiales y Lógica de Gráfico
function renderMaterialPanel(elementName) {
   const list = document.getElementById('materialPanelList');
   const panel = document.getElementById('materialPanel');
   const search = elementName.toLowerCase();
   
   // Filtramos las filas donde interviene el elemento seleccionado
   const rows = rawData.filter(r => 
       (r.de_elemento || '').toLowerCase() === search || 
       (r.para_elemento || '').toLowerCase() === search
   );
   
   const materialCounts = {};
 
   rows.forEach(r => {
       const esOrigen = (r.de_elemento || '').toLowerCase() === search;
       const esDestino = (r.para_elemento || '').toLowerCase() === search;
 
       // 1. Procesar Terminales (Mismo criterio que la barra lateral de conexiones)
       if (esOrigen && r.de_terminal && r.de_terminal !== 'S/T' && !isKN(r.de_terminal)) {
           const cod = r.de_terminal.toString().trim();
           if (!materialCounts[cod]) {
               materialCounts[cod] = { qty: 0, desc: masterMap.terminals[cod] || 'Sin descripción técnica' };
           }
           materialCounts[cod].qty += 1;
       }
       if (esDestino && r.para_terminal && r.para_terminal !== 'S/T' && !isKN(r.para_terminal)) {
           const cod = r.para_terminal.toString().trim();
           if (!materialCounts[cod]) {
               materialCounts[cod] = { qty: 0, desc: masterMap.terminals[cod] || 'Sin descripción técnica' };
           }
           materialCounts[cod].qty += 1;
       }
 
       // 2. Procesar Manguitos (Basado estrictamente en r.de_manguito por cable)
       // Como el manguito calza con el cable independientemente del sentido, evaluamos r.de_manguito
       if ((esOrigen || esDestino) && r.de_manguito && r.de_manguito !== 'S/M' && r.de_manguito !== 'S/E') {
           const cod = r.de_manguito.toString().trim();
           // Control estricto anti-cruce: Si coincide con la marca del cable por desfase, se ignora
           if (cod !== (r.cable_marca || '').toString().trim()) {
               if (!materialCounts[cod]) {
                   materialCounts[cod] = { qty: 0, desc: masterMap.sleeves[cod] || r.desc_manguito || 'Sin descripción técnica' };
               }
               materialCounts[cod].qty += 1;
           }
       }
   });
 
   const items = Object.entries(materialCounts);
   if (items.length === 0) {
       panel.classList.add('hidden');
       return;
   }
 
   list.innerHTML = items.map(([name, data]) => `
       <div class="p-2 border-b dark:border-slate-700 last:border-0 flex justify-between items-center text-xs">
           <div class="min-w-0 flex-1">
               <p class="font-bold text-sap-blue truncate">${name}</p>
               <p class="text-[10px] text-sap-secondaryText truncate">${data.desc}</p>
           </div>
           <span class="ml-3 px-2 py-0.5 bg-sap-blue/10 text-sap-blue font-black rounded-full text-[10px]">${data.qty} uds</span>
       </div>
   `).join('');
   
   panel.classList.remove('hidden');
   if (window.lucide) lucide.createIcons();
}
 
function openGraphicalView() { 
   const s = filterText.trim(); 
   if (!s) return; 
   
   // Obtener el elemento y asignar el texto
   const headerElement = document.getElementById('graphElementName');
   headerElement.innerText = s.toUpperCase(); 
   
   // Asociar el evento directamente sobre el elemento existente
   headerElement.onclick = function() {
       const panel = document.getElementById('materialPanel');
       if (panel.classList.contains('hidden')) {
           renderMaterialPanel(s);
           panel.classList.remove('hidden');
       } else {
           panel.classList.add('hidden');
       }
   };
   
   // Abrir el modal
   document.getElementById('materialPanel').classList.add('hidden');
   document.getElementById('graphModal').classList.remove('hidden'); 
   document.getElementById('graphModal').classList.add('flex'); 
   
   currentZoom = 1; panX = 0; panY = 0;
   drawDiagram(s);
  requestAnimationFrame(() => { fitDiagramToScreen(); });
}
 
function toggleMaterialPanel() {
   const s = filterText.trim();
   if (!s) return;
   const panel = document.getElementById('materialPanel');
   if (panel.classList.contains('hidden')) {
       renderMaterialPanel(s);
       panel.classList.remove('hidden');
   } else {
       panel.classList.add('hidden');
   }
}
 
function closeGraphicalView() { 
   document.getElementById('graphModal').classList.add('hidden'); 
   document.getElementById('materialPanel').classList.add('hidden'); // Cerramos panel
   hidePinPopover(); 
   updateView(); 
}
  
       
       function navigateToElement(t) { filterText = t; document.getElementById('filterInput').value = t; document.getElementById('elementQuickActions').classList.remove('hidden'); updateView(); drawDiagram(t); document.getElementById('graphElementName').innerText = t.toUpperCase(); }
       function markCurrentElementAsFinished() {
           const search = filterText.trim().toLowerCase();
           if (!search || rawData.length === 0) return;
 
           // 1. Recorremos todos los cables para identificar cuáles tocan este elemento
           rawData.forEach(r => {
               const isDe = (r.de_elemento || '').toLowerCase() === search;
               const isPara = (r.para_elemento || '').toLowerCase() === search;
 
               if (isDe || isPara) {
                   // Inicializamos el objeto si no existe
                   if (!progressMap[r.posicion]) {
                       progressMap[r.posicion] = { de: false, para: false };
                   }
                   
                   // Marcamos solo el extremo que corresponde al elemento actual
                   if (isDe) progressMap[r.posicion].de = true;
                   if (isPara) progressMap[r.posicion].para = true;
               }
           });
 
           // 2. Persistencia y actualización de datos de fondo
           saveProgress();
           registerChange();
           updateGlobalProgress();
           
           // 3. REFRESH VISUAL: Volvemos a dibujar el diagrama para que se vea todo verde
           // pero NO llamamos a closeGraphicalView(), así permaneces en la pantalla
           drawDiagram(search);
           
           // 4. Feedback visual opcional: un pequeño aviso de que se ha procesado
           const toast = document.getElementById('notificationToast');
           if (toast) {
               const span = toast.querySelector('span');
               if (span) span.innerText = `Elemento ${search.toUpperCase()} completado localmente`;
               toast.classList.add('show');
               setTimeout(() => toast.classList.remove('show'), 2000);
           }
       }
       
       function drawDiagram(elementName) {
   const svg = document.getElementById('diagramSvg'); if (!svg) return; svg.innerHTML = ''; 
   const search = elementName.toLowerCase();
   
   const allRelated = rawData.filter(r => (r.de_elemento||'').toLowerCase() === search || (r.para_elemento||'').toLowerCase() === search);
   const internalBridges = allRelated.filter(r => (r.de_elemento||'').toLowerCase() === search && (r.para_elemento||'').toLowerCase() === search);
 
   const pinMap = new Map(); 
   allRelated.forEach(c => {
       if ((c.de_elemento||'').toLowerCase() === search) {
           const p = c.de_punto;
           if (!pinMap.has(p)) pinMap.set(p, { in: [], out: [] });
           pinMap.get(p).out.push(c);
       }
       if ((c.para_elemento||'').toLowerCase() === search) {
           const p = c.para_punto;
           if (!pinMap.has(p)) pinMap.set(p, { in: [], out: [] });
           pinMap.get(p).in.push(c);
       }
   });
 
   const sortedPins = Array.from(pinMap.keys()).sort((a, b) => a.localeCompare(b, undefined, {numeric: true}));
   _schemaSortedPins = sortedPins; _schemaPinDataCache = {};
   const rowH = 80, colW = 350, mainW = 120; 
   const totalW = (colW * 2) + mainW + 100, totalH = (sortedPins.length * rowH) + 150;
   const pinYMap = {}; const mX = 50 + colW, sY = 80; 
   
   sortedPins.forEach((pin, i) => { pinYMap[pin] = sY + (i * rowH); });
    baseViewBox = { x: 0, y: 0, w: totalW, h: totalH }; updateViewBox();
   
   svg.innerHTML += `<rect x="${mX}" y="${sY-50}" width="${mainW}" height="35" rx="2" class="diag-header"/><text x="${mX+mainW/2}" y="${sY-28}" text-anchor="middle" fill="white" style="font-size:14px; font-weight:900">${elementName.toUpperCase()}</text>`;
   
   // 1. PUENTES INTERNOS
internalBridges.forEach((b, idx) => {
    const y1 = pinYMap[b.de_punto], y2 = pinYMap[b.para_punto];
    if (y1 === undefined || y2 === undefined) return;
    const arcX = mX + mainW + 40 + (idx * 20);
    const prog = progressMap[b.posicion] || { de: false, para: false };
    const bridgeColor = (prog.de && prog.para) ? '#10b981' : '#f97316';
    
    // Dibuja la manguera física del puente (Línea discontinua)
    svg.innerHTML += `<path d="M ${mX + mainW} ${y1} L ${arcX} ${y1} L ${arcX} ${y2} L ${mX + mainW} ${y2}" fill="none" stroke="${bridgeColor}" stroke-width="3" stroke-dasharray="6 3" opacity="0.8" />`;
    
    // [NUEVO] Dibuja los bornes o puntos de conexión del puente sobre el borde de la caja del elemento
    svg.innerHTML += `<circle cx="${mX + mainW}" cy="${y1}" r="4" fill="${bridgeColor}" stroke="${bridgeColor === '#10b981' ? '#059669' : '#ea580c'}" stroke-width="1" opacity="0.9" pointer-events="none" />`;
    svg.innerHTML += `<circle cx="${mX + mainW}" cy="${y2}" r="4" fill="${bridgeColor}" stroke="${bridgeColor === '#10b981' ? '#059669' : '#ea580c'}" stroke-width="1" opacity="0.9" pointer-events="none" />`;
    
    // Dibuja la etiqueta de texto con la marca del cable puente
    svg.innerHTML += ` <text x="${arcX + 14}" y="${(y1 + y2) / 2}" text-anchor="middle" class="diag-text-wire cursor-pointer" onclick="showInfoPopover(event, '${encodeURIComponent(JSON.stringify({type:'cable', label: b.cable_marca, posicion: b.posicion}))}')" transform="rotate(-90, ${arcX + 14}, ${(y1 + y2) / 2})" style="fill:${bridgeColor}; font-size:10px; font-weight:900; letter-spacing: 0.5px;"> ${b.cable_marca} </text>`;
});
 
      // 2. PINES Y CONEXIONES EXTERNAS
   sortedPins.forEach((pin) => {
       const y = pinYMap[pin], pD = pinMap.get(pin);
       
       // Formateo del popover usando las propiedades reales verificadas contra la marca
      const pCs = [
           ...pD.in.map(c => ({ 
               term: c.para_terminal, 
               sleeve: (c.de_manguito !== c.cable_marca) ? c.de_manguito : 'S/M', 
               label: c.cable_marca,
               posicion: c.posicion,
               observaciones: c.observaciones || ''
           })), 
           ...pD.out.map(c => ({ 
               term: c.de_terminal, 
               sleeve: (c.de_manguito !== c.cable_marca) ? c.de_manguito : 'S/M', 
               label: c.cable_marca,
               posicion: c.posicion,
               observaciones: c.observaciones || ''
           }))
       ];
       _schemaPinDataCache[pin] = pCs;
       
       const cablesConMarcaIn  = pD.in.filter(c => (c.cable_marca||'') !== '' && (c.de_elemento||'').toLowerCase() !== search);
       const cablesConMarcaOut = pD.out.filter(c => (c.cable_marca||'') !== '' && (c.para_elemento||'').toLowerCase() !== search);
       const totalPin    = cablesConMarcaIn.length + cablesConMarcaOut.length;
       const completadosPin = cablesConMarcaIn.filter(c => (progressMap[c.posicion]||{}).para === true).length
                            + cablesConMarcaOut.filter(c => (progressMap[c.posicion]||{}).de === true).length;
       const pinColor = totalPin === 0 ? '' 
                      : completadosPin === totalPin ? 'fill:#10b981; stroke:#059669;'
                      : completadosPin > 0          ? 'fill:#f97316; stroke:#ea580c;'
                      : '';
       const pinTextColor = document.documentElement.classList.contains('dark')
           ? '#ffffff'
           : (completadosPin === totalPin && totalPin > 0 ? '#ffffff' : '#0064d1');
       svg.innerHTML += `<rect x="${mX}" y="${y-15}" width="${mainW}" height="30" rx="2" class="diag-block diag-block-pin" style="${pinColor}" onclick="showInfoPopover(event, '${encodeURIComponent(JSON.stringify({type:'pin', pin, connections: pCs}))}')"/><text x="${mX+mainW/2}" y="${y+5}" text-anchor="middle" class="diag-text-main" style="fill:${pinTextColor}; pointer-events:none;">${pin}</text>`;
 
       const extIn = pD.in.filter(c => (c.de_elemento||'').toLowerCase() !== search);
       if (extIn.length > 0) {
           const stubX = mX - 100, blockRightEdge = stubX - 100;
           const anyLocalOk = extIn.some(c => (progressMap[c.posicion] || {}).para === true && (c.cable_marca||'') !== '');
           const extInConCable = extIn.filter(c => (c.cable_marca || '') !== '');
           extIn.forEach((c) => {
               const tieneCable = (c.cable_marca || '') !== '';
               const tieneObturador = !tieneCable && (c.para_terminal || '') !== '' && (c.para_terminal || '').toUpperCase() !== 'S/T' && !isKN(c.para_terminal);
               const isBusbar = (c.observaciones || '').trim().toUpperCase() === 'BUSBAR';
               if (!tieneCable && !tieneObturador && !isBusbar) return;
               if (isBusbar) return; // Renderizado en bloque BUSBAR post-loop
               if (tieneObturador) {
                   svg.innerHTML += `<circle cx="${mX + mainW - 8}" cy="${y + 8}" r="4" fill="#64748b" opacity="0.8" pointer-events="none"/>`;
                   return;
               }
               const idx = extInConCable.indexOf(c);
               const isLocalOk = (progressMap[c.posicion] || {}).para === true;
               const lY = extInConCable.length > 1 ? y+(idx-(extInConCable.length-1)/2)*32 : y;
               const xInicio = extInConCable.length > 1 ? stubX : mX;
               const lineStyle = isBusbar ? `stroke:#a855f7; stroke-dasharray:4 3;` : `${isLocalOk?'stroke:#10b981;':''}`;
               const wireLabel = isBusbar ? 'BUSBAR' : c.cable_marca;
               const wireColor = isBusbar ? '#a855f7' : `${isLocalOk?'fill:#10b981; font-weight:900;':'font-size: 9px;'}`;
               svg.innerHTML += `<line x1="${xInicio}" y1="${lY}" x2="${blockRightEdge}" y2="${lY}" class="diag-line" style="${lineStyle}"/>
                   <rect x="${blockRightEdge - 160}" y="${lY-12}" width="160" height="24" rx="2" class="diag-block diag-block-side" onclick="navigateToElement('${c.de_elemento}')"/>
                   <text x="${document.dir === 'rtl' ? blockRightEdge - 8 : blockRightEdge - 152}" y="${lY+4}" class="diag-text-main" style="font-size:11px; pointer-events:none;">${c.de_elemento.toUpperCase()}</text>
                   <text x="${document.dir === 'rtl' ? blockRightEdge - 150 : blockRightEdge - 10}" y="${lY+4}" text-anchor="${document.dir === 'rtl' ? 'start' : 'end'}" class="diag-text-label" style="font-weight:900; pointer-events:none;">${c.de_punto}</text>
                  <text x="${(xInicio + blockRightEdge) / 2}" y="${lY-8}" text-anchor="middle" class="diag-text-wire cursor-pointer" onclick="showInfoPopover(event, '${encodeURIComponent(JSON.stringify({type:'cable', label: wireLabel, posicion: c.posicion}))}')" style="${wireColor}">${wireLabel}</text>`;
           });
           if (extInConCable.length > 1) {
               svg.innerHTML += `<line x1="${mX}" y1="${y}" x2="${stubX}" y2="${y}" class="diag-line" style="${anyLocalOk?'stroke:#10b981;':''}"/>
                                 <line x1="${stubX}" y1="${y+(-(extInConCable.length-1)/2)*32}" x2="${stubX}" y2="${y+((extInConCable.length-1)/2)*32}" class="diag-line" style="${anyLocalOk?'stroke:#10b981;':''}"/>`;
           }
       }
 
       const extOut = pD.out.filter(c => (c.para_elemento||'').toLowerCase() !== search);
       if (extOut.length > 0) {
           const origX = mX + mainW, stubX = origX + 100, blockLeftEdge = stubX + 100;
           const anyLocalOk = extOut.some(c => (progressMap[c.posicion] || {}).de === true && (c.cable_marca||'') !== '');
           const extOutConCable = extOut.filter(c => (c.cable_marca || '') !== '');
           extOut.forEach((c) => {
               const tieneCable = (c.cable_marca || '') !== '';
               const tieneObturador = !tieneCable && (c.de_terminal || '') !== '' && (c.de_terminal || '').toUpperCase() !== 'S/T' && !isKN(c.de_terminal);
               const isBusbar = (c.observaciones || '').trim().toUpperCase() === 'BUSBAR';
               if (!tieneCable && !tieneObturador && !isBusbar) return;
               if (isBusbar) return; // Renderizado en bloque BUSBAR post-loop
               if (tieneObturador) {
                   svg.innerHTML += `<circle cx="${mX + mainW - 8}" cy="${y + 8}" r="4" fill="#64748b" opacity="0.8" pointer-events="none"/>`;
                   return;
               }
               const idx = extOutConCable.indexOf(c);
               const isLocalOk = (progressMap[c.posicion] || {}).de === true;
               const lY = extOutConCable.length > 1 ? y+(idx-(extOutConCable.length-1)/2)*32 : y;
               const xInicio = extOutConCable.length > 1 ? stubX : origX;
               const lineStyle = isBusbar ? `stroke:#a855f7; stroke-dasharray:4 3;` : `${isLocalOk?'stroke:#10b981;':''}`;
               const wireLabel = isBusbar ? 'BUSBAR' : c.cable_marca;
               const wireColor = isBusbar ? '#a855f7' : `${isLocalOk?'fill:#10b981; font-weight:900;':'font-size: 9px;'}`;
               svg.innerHTML += `<line x1="${xInicio}" y1="${lY}" x2="${blockLeftEdge}" y2="${lY}" class="diag-line" style="${lineStyle}"/>
                   <rect x="${blockLeftEdge}" y="${lY-12}" width="160" height="24" rx="2" class="diag-block diag-block-side" onclick="navigateToElement('${c.para_elemento}')"/>
                   <text x="${document.dir === 'rtl' ? blockLeftEdge + 10 : blockLeftEdge + 152}" y="${lY+4}" text-anchor="${document.dir === 'rtl' ? 'start' : 'end'}" class="diag-text-main" style="font-size:11px; pointer-events:none;">${c.para_elemento.toUpperCase()}</text>
                   <text x="${document.dir === 'rtl' ? blockLeftEdge + 150 : blockLeftEdge + 10}" y="${lY+4}" class="diag-text-label" style="font-weight:900; pointer-events:none;">${c.para_punto}</text>
                  <text x="${(xInicio + blockLeftEdge) / 2}" y="${lY-8}" text-anchor="middle" class="diag-text-wire cursor-pointer" onclick="showInfoPopover(event, '${encodeURIComponent(JSON.stringify({type:'cable', label: wireLabel, posicion: c.posicion}))}')" style="${wireColor}">${wireLabel}</text>`;
           });
           if (extOutConCable.length > 1) {
               svg.innerHTML += `<line x1="${origX}" y1="${y}" x2="${stubX}" y2="${y}" class="diag-line" style="${anyLocalOk?'stroke:#10b981;':''}"/>
                                 <line x1="${stubX}" y1="${y+(-(extOutConCable.length-1)/2)*32}" x2="${stubX}" y2="${y+((extOutConCable.length-1)/2)*32}" class="diag-line" style="${anyLocalOk?'stroke:#10b981;':''}"/>`;
           }
       }
   });

   // ---- REPRESENTACIÓN VISUAL DEL BUSBAR ----
   // Los BUSBAR se renderizan como grupo: barra vertical física + línea punteada a destino.
   // Esto refleja la realidad física del busbar (barra que une varios puntos de conexión).
   const origX_bb = mX + mainW;
   const stubX_bb = origX_bb + 100;
   const destX_bb = stubX_bb + 100;

   // a) BUSBAR SALIENTES (de_elemento = elemento actual)
   const busbarOutGroups = {};
   allRelated.forEach(c => {
       if ((c.de_elemento||'').toLowerCase() !== search) return;
       if ((c.para_elemento||'').toLowerCase() === search) return;
       if ((c.observaciones||'').trim().toUpperCase() !== 'BUSBAR') return;
       if (pinYMap[c.de_punto] === undefined) return;
       const k = (c.para_elemento||'').toLowerCase();
       if (!busbarOutGroups[k]) busbarOutGroups[k] = [];
       busbarOutGroups[k].push(c);
   });
   Object.entries(busbarOutGroups).forEach(([, conns]) => {
       conns.sort((a, b) => String(a.de_punto).localeCompare(String(b.de_punto), undefined, {numeric:true}));
       const ys = conns.map(c => pinYMap[c.de_punto]);
       const minY = Math.min(...ys), maxY = Math.max(...ys);
       const midY = (minY + maxY) / 2;
       const barX = origX_bb + 8;

       // Líneas cortas de cada pin al barX
       conns.forEach(c => {
           const py = pinYMap[c.de_punto];
           svg.innerHTML += `<line x1="${origX_bb}" y1="${py}" x2="${barX}" y2="${py}" class="diag-line" style="stroke:#a855f7; stroke-dasharray:3 2;"/>`;
       });
       // Barra vertical (el busbar físico)
       svg.innerHTML += `<line x1="${barX}" y1="${minY - 14}" x2="${barX}" y2="${maxY + 14}" class="diag-line" style="stroke:#a855f7; stroke-width:5; stroke-linecap:round;" pointer-events="none"/>`;
       // Círculos en cada punto de conexión
       conns.forEach(c => {
           svg.innerHTML += `<circle cx="${barX}" cy="${pinYMap[c.de_punto]}" r="5" fill="#a855f7" stroke="#7c3aed" stroke-width="1.5" pointer-events="none"/>`;
       });
       // Etiqueta BUSBAR rotada
       if (conns.length > 1) {
           svg.innerHTML += `<text x="${barX + 15}" y="${midY}" text-anchor="middle" transform="rotate(-90, ${barX + 15}, ${midY})" style="fill:#a855f7; font-size:9px; font-weight:900; letter-spacing:0.5px;" pointer-events="none">BUSBAR</text>`;
       }
       // Ruta punteada por debajo de los pines BUSBAR → evita superposición con cables
       const bbRouteY = maxY + 35;
       svg.innerHTML += `<line x1="${barX}" y1="${maxY + 14}" x2="${barX}" y2="${bbRouteY}" class="diag-line" style="stroke:#a855f7; stroke-dasharray:4 3;"/>`;
       svg.innerHTML += `<line x1="${barX}" y1="${bbRouteY}" x2="${destX_bb}" y2="${bbRouteY}" class="diag-line" style="stroke:#a855f7; stroke-dasharray:4 3;"/>`;
       // Bloque destino
       const para_elem = conns[0].para_elemento;
       svg.innerHTML += `<rect x="${destX_bb}" y="${bbRouteY - 12}" width="160" height="24" rx="2" class="diag-block diag-block-side" onclick="navigateToElement('${para_elem}')"/>`;
       svg.innerHTML += `<text x="${destX_bb + 8}" y="${bbRouteY + 4}" class="diag-text-main" style="font-size:11px; pointer-events:none;">${para_elem.toUpperCase()}</text>`;
       const ptsOut = conns.map(c => c.para_punto).join(', ');
       svg.innerHTML += `<text x="${destX_bb + 152}" y="${bbRouteY + 4}" text-anchor="end" class="diag-text-label" style="font-weight:900; font-size:9px; pointer-events:none;">${ptsOut}</text>`;
   });

   // b) BUSBAR ENTRANTES (para_elemento = elemento actual)
   const mXLeft_bb = mX;
   const stubXLeft_bb = mXLeft_bb - 100;
   const destXLeft_bb = stubXLeft_bb - 100;
   const busbarInGroups = {};
   allRelated.forEach(c => {
       if ((c.para_elemento||'').toLowerCase() !== search) return;
       if ((c.de_elemento||'').toLowerCase() === search) return;
       if ((c.observaciones||'').trim().toUpperCase() !== 'BUSBAR') return;
       if (pinYMap[c.para_punto] === undefined) return;
       const k = (c.de_elemento||'').toLowerCase();
       if (!busbarInGroups[k]) busbarInGroups[k] = [];
       busbarInGroups[k].push(c);
   });
   Object.entries(busbarInGroups).forEach(([, conns]) => {
       conns.sort((a, b) => String(a.para_punto).localeCompare(String(b.para_punto), undefined, {numeric:true}));
       const ys = conns.map(c => pinYMap[c.para_punto]);
       const minY = Math.min(...ys), maxY = Math.max(...ys);
       const midY = (minY + maxY) / 2;
       const barX = mXLeft_bb - 8;

       // Líneas cortas de cada pin al barX
       conns.forEach(c => {
           const py = pinYMap[c.para_punto];
           svg.innerHTML += `<line x1="${barX}" y1="${py}" x2="${mXLeft_bb}" y2="${py}" class="diag-line" style="stroke:#a855f7; stroke-dasharray:3 2;"/>`;
       });
       // Barra vertical
       svg.innerHTML += `<line x1="${barX}" y1="${minY - 14}" x2="${barX}" y2="${maxY + 14}" class="diag-line" style="stroke:#a855f7; stroke-width:5; stroke-linecap:round;" pointer-events="none"/>`;
       // Círculos
       conns.forEach(c => {
           svg.innerHTML += `<circle cx="${barX}" cy="${pinYMap[c.para_punto]}" r="5" fill="#a855f7" stroke="#7c3aed" stroke-width="1.5" pointer-events="none"/>`;
       });
       // Etiqueta
       if (conns.length > 1) {
           svg.innerHTML += `<text x="${barX - 15}" y="${midY}" text-anchor="middle" transform="rotate(-90, ${barX - 15}, ${midY})" style="fill:#a855f7; font-size:9px; font-weight:900; letter-spacing:0.5px;" pointer-events="none">BUSBAR</text>`;
       }
       // Ruta punteada por debajo de los pines BUSBAR → evita superposición con cables
       const bbRouteY = maxY + 35;
       svg.innerHTML += `<line x1="${barX}" y1="${maxY + 14}" x2="${barX}" y2="${bbRouteY}" class="diag-line" style="stroke:#a855f7; stroke-dasharray:4 3;"/>`;
       svg.innerHTML += `<line x1="${destXLeft_bb + 160}" y1="${bbRouteY}" x2="${barX}" y2="${bbRouteY}" class="diag-line" style="stroke:#a855f7; stroke-dasharray:4 3;"/>`;
       // Bloque origen
       const de_elem = conns[0].de_elemento;
       svg.innerHTML += `<rect x="${destXLeft_bb}" y="${bbRouteY - 12}" width="160" height="24" rx="2" class="diag-block diag-block-side" onclick="navigateToElement('${de_elem}')"/>`;
       svg.innerHTML += `<text x="${destXLeft_bb + 8}" y="${bbRouteY + 4}" class="diag-text-main" style="font-size:11px; pointer-events:none;">${de_elem.toUpperCase()}</text>`;
       const ptsIn = conns.map(c => c.de_punto).join(', ');
       svg.innerHTML += `<text x="${destXLeft_bb + 152}" y="${bbRouteY + 4}" text-anchor="end" class="diag-text-label" style="font-weight:900; font-size:9px; pointer-events:none;">${ptsIn}</text>`;
   });

   if (window.lucide) lucide.createIcons();
}
 
       function globalSearchNext() { 
           const q = document.getElementById('globalSearchInput').value.trim().toLowerCase(), c = document.getElementById('searchCounter'), rs = Array.from(document.querySelectorAll('#tableBody tr'));
           if (!q) { currentMatchIdx = -1; c.innerText = ''; rs.forEach(r => r.classList.remove('search-row-match')); return; }
           const ms = rs.filter(row => row.innerText.toLowerCase().includes(q)); if (ms.length === 0) { c.innerText = '0/0'; return; }
           currentMatchIdx = (currentMatchIdx + 1) % ms.length; rs.forEach(r => r.classList.remove('search-row-match'));
           ms[currentMatchIdx].classList.add('search-row-match'); ms[currentMatchIdx].scrollIntoView({ behavior: 'smooth', block: 'center' });
           c.innerText = `${currentMatchIdx + 1}/${ms.length}`;
       }
       function selectConnectionRow(event, row) {
           if (event.target.closest('button, input, i')) return;
           selectedConnectionPosition = decodeURIComponent(row.dataset.position);
           document.querySelectorAll('#tableBody tr.row-selected').forEach(selectedRow => selectedRow.classList.remove('row-selected'));
           row.classList.add('row-selected');
       }
       function startResize(e, col) { resizingCol = col; startX = e.clientX; startWidth = col.width; e.preventDefault(); }
       function hTHDragStart(e, i) { thDragIdx = i; }
       function hTHDragOver(e) { e.preventDefault(); }
       function hTHDrop(e, tIdx) { e.preventDefault(); const a = columns.filter(c => c.visible), d = a[thDragIdx], t = a[tIdx]; if(!d || !t) return; const rs = columns.findIndex(c => c.id === d.id), rd = columns.findIndex(c => c.id === t.id); columns.splice(rd, 0, columns.splice(rs, 1)[0]); updateView(); }
 
       // --- FUNCIONES ESPECÍFICAS CRIMPAR ---
 
       function getCrimpingInfo(terminalId, seccion) {
           if (!terminalId || !seccion) return null;
           const normSection = seccion.toString().replace('.', ',');
           const idToSearch = terminalId.toString().trim().toUpperCase();
           return crimpingMasterData.find(item => 
               item.id.toString().toUpperCase() === idToSearch && 
               item.seccion === normSection
           );
       }

       function checkSectionCompatibility(terminalId, seccion) {
           if (!terminalId || !seccion) return null;
           const idToSearch = terminalId.toString().trim().toUpperCase();
           const termEntries = crimpingMasterData.filter(item => item.id.toString().toUpperCase() === idToSearch);
           if (termEntries.length === 0) return null; // terminal sin datos de crimpado, sin validación
           const normSection = seccion.toString().replace('.', ',');
           if (termEntries.some(item => item.seccion === normSection)) return { ok: true };
           return { ok: false, validSections: termEntries.map(item => item.seccion) };
       }

       function showCellErrorTip(el, scheme, titleText, bodyHtml) {
           const schemes = {
               red:    { border:'border-red-300 dark:border-red-700',      icon:'w-4 h-4 shrink-0 text-red-500',    title:'text-[11px] font-black uppercase tracking-wide text-red-600 dark:text-red-400',    body:'text-[10px] leading-snug space-y-0.5 text-red-500 dark:text-red-400',    hint:'text-[9px] mt-2 italic text-red-300 dark:text-red-600' },
               orange: { border:'border-orange-300 dark:border-orange-700', icon:'w-4 h-4 shrink-0 text-orange-500', title:'text-[11px] font-black uppercase tracking-wide text-orange-600 dark:text-orange-400', body:'text-[10px] leading-snug space-y-0.5 text-orange-600 dark:text-orange-400', hint:'text-[9px] mt-2 italic text-orange-300 dark:text-orange-600' },
               amber:  { border:'border-amber-300 dark:border-amber-700',   icon:'w-4 h-4 shrink-0 text-amber-600',  title:'text-[11px] font-black uppercase tracking-wide text-amber-700 dark:text-amber-400',  body:'text-[10px] leading-snug space-y-0.5 text-amber-600 dark:text-amber-400',  hint:'text-[9px] mt-2 italic text-amber-300 dark:text-amber-600' },
               purple: { border:'border-purple-300 dark:border-purple-700', icon:'w-4 h-4 shrink-0 text-purple-500', title:'text-[11px] font-black uppercase tracking-wide text-purple-600 dark:text-purple-400', body:'text-[10px] leading-snug space-y-0.5 text-purple-500 dark:text-purple-400', hint:'text-[9px] mt-2 italic text-purple-300 dark:text-purple-600' },
               pink:   { border:'border-pink-300 dark:border-pink-700',     icon:'w-4 h-4 shrink-0 text-pink-500',   title:'text-[11px] font-black uppercase tracking-wide text-pink-600 dark:text-pink-400',   body:'text-[10px] leading-snug space-y-0.5 text-pink-500 dark:text-pink-400',   hint:'text-[9px] mt-2 italic text-pink-300 dark:text-pink-600' },
               emerald:{ border:'border-emerald-300 dark:border-emerald-700', icon:'w-4 h-4 shrink-0 text-emerald-500', title:'text-[11px] font-black uppercase tracking-wide text-emerald-600 dark:text-emerald-400', body:'text-[10px] leading-snug space-y-0.5 text-emerald-500 dark:text-emerald-400', hint:'text-[9px] mt-2 italic text-emerald-300 dark:text-emerald-600' },
               brown:  { border:'border-amber-300 dark:border-amber-700',   icon:'w-4 h-4 shrink-0 text-[#a67c52]',  title:'text-[11px] font-black uppercase tracking-wide text-[#8f6b45]',  body:'text-[10px] leading-snug space-y-0.5 text-[#a67c52]',  hint:'text-[9px] mt-2 italic text-[#c4a17a]' },
           };
           const tip     = document.getElementById('cellErrorTip');
           const card    = document.getElementById('cellErrorTipCard');
           const icon    = document.getElementById('cellErrorTipIcon');
           const titleEl = document.getElementById('cellErrorTipTitle');
           const bodyEl  = document.getElementById('cellErrorTipBody');
           const hintEl  = document.getElementById('cellErrorTipHint');
           if (!tip || !card) return;
           clearTimeout(_termTipTimeout);
           const s = schemes[scheme] || schemes.red;
           card.className    = `bg-white dark:bg-slate-800 border ${s.border} rounded-xl shadow-2xl p-3 text-left`;
           icon.setAttribute('class', s.icon);
           titleEl.className = s.title;
           titleEl.textContent = titleText;
           bodyEl.className  = s.body;
           bodyEl.innerHTML  = bodyHtml;
           hintEl.className  = s.hint;
           tip.classList.remove('hidden');
           const rect = el.getBoundingClientRect();
           const tipH = tip.offsetHeight || 90;
           const top  = rect.top > tipH + 10 ? rect.top - tipH - 6 : rect.bottom + 6;
           tip.style.top  = top + 'px';
           tip.style.left = Math.max(8, Math.min(rect.left, window.innerWidth - 272)) + 'px';
           _termTipTimeout = setTimeout(hideCellErrorTip, 4000);
           setTimeout(() => { document.addEventListener('touchstart', hideCellErrorTip, { once: true, capture: true }); }, 150);
       }
       function hideCellErrorTip() {
           clearTimeout(_termTipTimeout);
           _termTipTimeout = null;
           const tip = document.getElementById('cellErrorTip');
           if (tip) tip.classList.add('hidden');
       }
       function showTermCompatTip(el, termId, seccion, validSections) {
           showCellErrorTip(el, 'red', 'SECCI\u00d3N INCOMPATIBLE',
               `<p>El terminal <strong>${termId}</strong> no admite <strong>${seccion} mm\u00b2</strong>.</p><p>V\u00e1lidas: <strong>${validSections} mm\u00b2</strong></p>`);
       }
       function hideTermCompatTip() { hideCellErrorTip(); }
 
 function openCrimpingModal(terminalId, seccion) {
           const data = getCrimpingInfo(terminalId, seccion);
           if (!data) return;
 
           const modal = document.getElementById('crimpingModal');
           const content = document.getElementById('crimpingModalContent');
           const imgFallback = "this.onerror=null; this.src='https://placehold.co/400x300?text=Imagen+no+disponible';";
 
           // Determinar si existen accesorios
           const hasAccessories = data.txt_pos || data.img_regul;
 
           content.innerHTML = `
               <div class="flex flex-col gap-4 text-left">
                   <!-- Cabecera de Datos -->
                   <div class="bg-white dark:bg-sap-darkCard border border-sap-border rounded-xl shadow-sm flex items-center px-6 py-2 gap-8">
                       <div class="w-16 h-12 bg-white border border-gray-100 rounded flex-shrink-0 flex items-center justify-center p-1">
                           <img src="${CRIMP_PATHS.terminales}${data.img_pin}.jpg" class="max-h-full max-w-full object-contain" onerror="${imgFallback}">
                       </div>
                       <div class="flex items-center gap-12 flex-grow text-left">
                           <div><p class="text-[8px] text-sap-secondaryText font-black uppercase tracking-wider">Terminal</p><p class="text-sm font-black text-sap-blue">${terminalId}</p></div>
                           <div class="min-w-0 flex-1"><p class="text-[8px] text-sap-secondaryText font-black uppercase tracking-wider">Descripción</p><p class="text-xs font-bold text-sap-text dark:text-white truncate max-w-[400px]">${data.txt_pin}</p></div>
                           <div><p class="text-[8px] text-sap-secondaryText font-black uppercase tracking-wider">Sección</p><p class="text-sm font-black text-sap-text dark:text-white">${data.seccion} mm²</p></div>
                       </div>
                   </div>
 
                   <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                       <div class="flex flex-col gap-0">
                           <!-- PANEL 1: PELADO -->
                           <div class="bg-white dark:bg-sap-darkCard border border-sap-border rounded-xl shadow-sm overflow-hidden flex flex-col">
                               <div class="card-header-uniform">
                                <span class="title-text">INSTRUCCIONES DE PELADO</span>
                            </div>
                               <div class="p-4 flex flex-col">
                                   <div class="bg-white rounded-lg flex items-center justify-center p-2 mb-3 h-48 border border-gray-50 shadow-inner overflow-hidden">
                                       <img src="${CRIMP_PATHS.pelacables}${data.img_pela}.jpg" class="max-h-full w-full object-contain" onerror="${imgFallback}">
                                   </div>
                                   <div class="space-y-2">
                                       <div><p class="text-[9px] text-sap-secondaryText font-black uppercase tracking-tighter">Herramienta</p><p class="text-sm font-black text-sap-text dark:text-white leading-tight">${data.txt_pela}</p></div>
                                       <div class="pt-2 border-t border-emerald-100 mt-1">
                                           <span class="text-[9px] font-black text-emerald-800/60 uppercase tracking-tight">LONGITUD:</span>
                                           <span class="text-base font-black text-emerald-600 tabular-nums ml-1">${data.txt_longitud} mm</span>
                                       </div>
                                   </div>
                               </div>
                           </div>

                           ${data.txt_ext && data.img_ext ? `
                           <!-- PANEL EXTRACTOR -->
                           <div class="bg-white dark:bg-sap-darkCard border border-sap-border rounded-xl shadow-sm overflow-hidden flex flex-col">
                               <div class="card-header-uniform">
                                <span class="title-text">EXTRACTOR</span>
                            </div>
                               <div class="p-2 flex items-center gap-3">
                                   <div class="w-20 h-14 bg-white border border-gray-200 rounded flex-shrink-0 flex items-center justify-center p-1">
                                       <img src="${CRIMP_PATHS.extractores}${data.img_ext}.jpg" class="max-h-full w-full object-contain" onerror="${imgFallback}">
                                   </div>
                                   <p class="text-xs font-black text-sap-text dark:text-white truncate">${data.txt_ext}</p>
                               </div>
                           </div>
                           ` : ''}
                       </div>
 
                       <!-- PANEL 2: CRIMPADO (Dinámico) -->
                       <div class="h-full bg-white dark:bg-sap-darkCard border-2 border-sap-blue/30 rounded-xl shadow-md overflow-hidden flex flex-col text-left">
                           <div class="card-header-uniform">
                            <span class="title-text">HERRAMIENTA DE CRIMPADO</span>
                            <div class="px-2 py-0.5 bg-white/20 rounded text-[10px] font-bold text-white">Matriz: ${data.txt_matriz || 'N/A'}</div>
                        </div>
                           
                           <div class="p-4 flex flex-col gap-4 flex-grow">
                               ${!hasAccessories ? `
                                   <!-- MODO GRANDE: Sin accesorios, la tenaza ocupa todo -->
                                   <div class="flex flex-col flex-grow">
                                       <div class="bg-white rounded-lg flex items-center justify-center p-4 mb-4 h-64 border border-gray-50 shadow-inner overflow-hidden">
                                           <img src="${CRIMP_PATHS.crimpadoras}${data.img_tenaza}.jpg" class="max-h-full w-full object-contain" onerror="${imgFallback}">
                                       </div>
                                       <div class="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200">
                                           <p class="text-[9px] text-sap-secondaryText font-black uppercase tracking-wider text-center">Tenaza (Vista General)</p>
                                           <p class="text-sm font-black text-sap-text dark:text-white text-center">${data.txt_tenaza}</p>
                                       </div>
                                   </div>
                               ` : `
                                   <!-- MODO DETALLE: Con accesorios, estructura reducida -->
                                   <div class="flex items-center gap-4 p-2 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200">
                                       <div class="w-20 h-14 bg-white border border-gray-200 rounded flex-shrink-0 flex items-center justify-center p-1">
                                           <img src="${CRIMP_PATHS.crimpadoras}${data.img_tenaza}.jpg" class="max-h-full w-full object-contain" onerror="${imgFallback}">
                                       </div>
                                       <div class="min-w-0 flex-1">
                                           <p class="text-[8px] text-sap-secondaryText font-black uppercase tracking-wider">Tenaza</p>
                                           <p class="text-xs font-black text-sap-text dark:text-white truncate">${data.txt_tenaza}</p>
                                       </div>
                                   </div>
                                   <div class="grid grid-cols-2 gap-3 flex-grow">
                                       <div class="bg-amber-50 dark:bg-amber-900/10 border border-amber-200 rounded-xl p-3 flex flex-col items-center justify-between">
                                           <p class="text-[9px] text-amber-700 font-black uppercase mb-1 tracking-tighter text-center">Posicionador</p>
                                           <div class="w-full h-44 bg-white rounded border border-amber-100 flex items-center justify-center p-1 overflow-hidden shadow-sm">
                                               <img src="${CRIMP_PATHS.posicionadores}${data.img_pos}.jpg" class="max-h-full w-auto object-contain" onerror="${imgFallback}">
                                           </div>
                                           <p class="text-[10px] font-bold text-sap-text dark:text-white mt-2 text-center leading-tight">${data.txt_pos}</p>
                                       </div>
                                       ${data.img_regul ? `
                                       <div class="bg-blue-50 dark:bg-blue-900/10 border border-sap-blue/20 rounded-xl p-3 flex flex-col items-center justify-between">
                                           <p class="text-[9px] text-sap-blue font-black uppercase mb-1 tracking-tighter text-center">Regulación</p>
                                           <div class="w-full h-44 bg-white rounded border border-sap-blue/10 flex items-center justify-center p-1 overflow-hidden shadow-sm">
                                               <img src="${CRIMP_PATHS.regulacion}${data.img_regul.trim()}.jpg" class="max-h-full w-auto object-contain" onerror="${imgFallback}">
                                           </div>
                                           <p class="text-[10px] font-black text-sap-blue mt-2 text-center uppercase">Selector: ${data.img_regul}</p>
                                       </div>
                                       ` : ''}
                                   </div>
                               `}
                           </div>
                       </div>
 
                       <!-- PANEL 3: CALIDAD (Ancho completo abajo) -->
                       <div class="md:col-span-2 bg-white dark:bg-sap-darkCard border border-sap-border rounded-xl shadow-sm overflow-hidden flex flex-col">
                           <div class="card-header-uniform">
                            <span class="title-text">AYUDA VISUAL / CRITERIO DE CALIDAD</span>
                        </div>
                           <div class="p-4">
                               <div class="flex flex-col items-center justify-center bg-white h-80 shadow-inner">
                               <img src="${CRIMP_PATHS.ayuda}${data.img_obs}.jpg" class="max-h-full w-auto object-contain" onerror="${imgFallback}">
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           `;
           
           modal.classList.remove('hidden');
           modal.classList.add('flex');
           if (window.lucide) lucide.createIcons();
       }
 
       function closeCrimpingModal() {
           const modal = document.getElementById('crimpingModal');
           modal.classList.add('hidden');
           modal.classList.remove('flex');
       }
function handleHelpEasterEgg() {
   const msgBox = document.getElementById('easterEggMessage');
   if (!msgBox) return;
 
   // Reiniciar el temporizador en cada clic
   clearTimeout(helpClickTimer);
   
   // Si el mensaje ya se está mostrando, ignorar clics adicionales
   if (!msgBox.classList.contains('hidden')) return;
 
   helpClickCount++;
 
   // Si pasan más de 2 segundos entre clics, la cuenta vuelve a 0
   helpClickTimer = setTimeout(() => {
       helpClickCount = 0;
   }, 2000);
 
   // Al llegar a 7 clics
   if (helpClickCount === 7) {
       msgBox.classList.remove('hidden');
       msgBox.classList.add('block');
       
       // El mensaje se oculta automáticamente a los 10 segundos
       setTimeout(() => {
           msgBox.classList.add('hidden');
           msgBox.classList.remove('block');
           helpClickCount = 0; // Resetear cuenta para poder activarlo de nuevo
       }, 10000);
       
       helpClickCount = 0;
   }
}
// --- FUNCIONES DE RENDERIZADO DE TABLA Y VISTAS ---
       function updateView() { 
           const tV = document.getElementById('tableView'); 
           const sV = document.getElementById('summaryView'); 
           if (currentView === 'table') { 
               tV.classList.remove('hidden'); 
               sV.classList.add('hidden'); 
               renderTable(); 
           } else { 
               tV.classList.add('hidden'); 
               sV.classList.remove('hidden'); 
               renderSummary(); 
           } 
           lucide.createIcons(); 
       }
 
       function renderTable() {
           const h = document.getElementById('tableHeader'), b = document.getElementById('tableBody'), a = columns.filter(c => c.visible);

           // Pre-filtrado (elemento + marca) para poder detectar errores de terminal antes de generar la cabecera
           let d = [...rawData];
           if (filterText.trim()) {
               const terms = filterText.split('+').map(t => t.trim().toLowerCase()).filter(t => t);
               d = d.filter(r => { const de = (r.de_elemento||'').toLowerCase(), para = (r.para_elemento||'').toLowerCase(); return terms.some(s => de===s || para===s); });
           }
           if (filterMarcaText.trim()) {
               const terms = filterMarcaText.split('+').map(t => t.trim().toLowerCase()).filter(t => t);
               d = d.filter(r => { const marca = (r.cable_marca||'').toLowerCase(); return terms.some(s => marca.includes(s)); });
           }

           // Pre-scan: detectar si hay filas con incompatibilidad de sección en cada columna de terminal
           const _hasTermError = key => d.some(r => {
               const v = r[key] || '';
               if (!v || v === 'S/T' || isKN(v) || !r.seccion) return false;
               const sc = checkSectionCompatibility(v, r.seccion);
               return sc && !sc.ok;
           });
           const hasDeTerminalErrors   = _hasTermError('de_terminal');
           const hasParaTerminalErrors = _hasTermError('para_terminal');

           // Pre-scan: detectar si hay terminales que no existen en master-data.js
           const _hasTermNotFound = key => d.some(r => {
               const v = r[key] || '';
               if (!v || isKN(v)) return false;
               return !isValidTerminalCode(v);
           });
           const hasDeTerminalNotFound   = _hasTermNotFound('de_terminal');
           const hasParaTerminalNotFound = _hasTermNotFound('para_terminal');
           const hasCableNotFound = d.some(r => r.cod_cable && !isValidCableCode(r.cod_cable));
           const hasSleeveNotFound = d.some(r => r.de_manguito && !isValidSleeveCode(r.de_manguito));

           // Pre-scan: detectar si hay filas con sección vacía pero con terminal asignado
           const _tvh = t => !!(t && t !== 'S/T' && t !== 'S/M' && !isKN(t));
           const hasSeccionMissingErrors = d.some(r => !r.seccion && (_tvh(r.de_terminal) || _tvh(r.para_terminal)));
           const hasDupPosicion = _dupPosicions.size > 0;
           const hasDupOrden    = _dupOrdenes.size > 0;
           const hasNonNumericLongitud = _nonNumericLongitud.size > 0;

           // 1. Generar Cabecera
           h.innerHTML = `<tr class="bg-sap-shell text-white">${a.map((c, i) => {
               const isSorted = currentSortCol === c.key;
               const sortIcon = isSorted ? (sortAsc ? ' <i data-lucide="chevron-up" class="inline w-3 h-3"></i>' : ' <i data-lucide="chevron-down" class="inline w-3 h-3"></i>') : '';
               const colHasTermErrors = (c.key === 'de_terminal' && hasDeTerminalErrors) || (c.key === 'para_terminal' && hasParaTerminalErrors);
               const colHasTermNotFound = (c.key === 'de_terminal' && hasDeTerminalNotFound) || (c.key === 'para_terminal' && hasParaTerminalNotFound);
               const colHasCableNotFound = c.key === 'cod_cable' && hasCableNotFound;
               const colHasSleeveNotFound = c.key === 'de_manguito' && hasSleeveNotFound;
               const colHasDupErrors  = (c.key === 'posicion' && hasDupPosicion) || (c.key === 'orden' && hasDupOrden);
               const colHasSecErrors  = c.key === 'seccion' && hasSeccionMissingErrors;
               const colHasNonNumLong = c.key === 'longitud' && hasNonNumericLongitud;
               const errorIndicators = [];
               if (colHasDupErrors) errorIndicators.push({ type: 'duplicate', color: 'text-orange-300', title: 'Valores duplicados en esta columna' });
               if (colHasSecErrors) errorIndicators.push({ type: 'missingSection', color: 'text-amber-300', title: 'Terminal asignado con sección sin definir' });
               if (colHasTermErrors) errorIndicators.push({ type: 'incompatible', color: 'text-red-300', title: 'Terminal incompatible con la sección' });
               if (colHasNonNumLong) errorIndicators.push({ type: 'nonNumericLength', color: 'text-purple-300', title: 'Longitud con caracteres no numéricos' });
               if (colHasTermNotFound) errorIndicators.push({ type: 'notFound', color: 'text-pink-300', title: 'Terminal o pin no existe en master-data.js' });
               if (colHasCableNotFound) errorIndicators.push({ type: 'cableNotFound', color: 'text-emerald-300', title: 'ID CABLE no existe en master-data.js' });
               if (colHasSleeveNotFound) errorIndicators.push({ type: 'sleeveNotFound', color: 'text-[#c49a6c]', title: 'DE MANGUITO no existe en master-data.js' });
               const warnIcon = errorIndicators.map(error => {
                   const filterId = `${c.key}:${error.type}`;
                   const isFiltered = filterTerminalError === filterId;
                   const title = isFiltered ? `Mostrando solo este tipo de error — clic para quitar filtro` : `${error.title} — clic para filtrar`;
                   const color = isFiltered ? 'text-yellow-300' : `${error.color} term-warn-blink`;
                   return `<i data-lucide="triangle-alert" class="w-3 h-3 shrink-0 ${color} cursor-pointer" title="${title}" onclick="event.stopPropagation(); toggleTerminalErrorFilter('${filterId}')"></i>`;
               }).join('');
               return `<th class="p-3 text-[10px] font-black uppercase border-r border-white/10 text-left relative cursor-pointer hover:bg-white/10 active:bg-sap-darkBlue transition-all select-none bg-sap-shell" 
                           style="width: ${c.width}px; min-width: ${c.width}px;" 
                           draggable="true" 
                           ondragstart="hTHDragStart(event, ${i})" 
                           ondragover="hTHDragOver(event)" 
                           ondrop="hTHDrop(event, ${i})"
                           onclick="sortTable('${c.key}')">
                           <span class="flex items-center gap-1">${c[currentLang]||c.en}${warnIcon}${sortIcon}</span>
                           <div class="resizer" onmousedown="event.stopPropagation(); startResize(event, columns.find(col => col.id === '${c.id}'))"></div>
                       </th>`;
          }).join('')}<th class="p-3 w-20 text-center bg-sap-shell border-l border-white/10">
    <div class="flex items-center justify-center gap-2">
        <i data-lucide="alert-triangle" class="w-3.5 h-3.5 text-red-300 ${incidenciaModeActive ? '' : 'hidden'}" id="thIncidenciaIcon" title="Modo incidencias activo"></i>
        <button onclick="event.stopPropagation(); toggleColConfig()"><i data-lucide="settings" class="w-4 h-4"></i></button>
    </div>
</th></tr>`;

           // 2. Filtrado por error de columna (sobre los ya pre-filtrados)
           if (filterTerminalError) {
               const [filterColumn, filterType] = filterTerminalError.split(':');
               if (filterColumn === 'posicion' && filterType === 'duplicate') {
                   d = d.filter(r => _dupPosicions.has((r.posicion||'').toString().trim()));
               } else if (filterColumn === 'orden' && filterType === 'duplicate') {
                   d = d.filter(r => _dupOrdenes.has((r.orden||'').toString().trim()));
               } else if (filterColumn === 'seccion' && filterType === 'missingSection') {
                   d = d.filter(r => !r.seccion && (_tvh(r.de_terminal) || _tvh(r.para_terminal)));
               } else if (filterColumn === 'longitud' && filterType === 'nonNumericLength') {
                   d = d.filter(r => _nonNumericLongitud.has((r.posicion||'').toString().trim()));
               } else if (filterColumn === 'cod_cable' && filterType === 'cableNotFound') {
                   d = d.filter(r => r.cod_cable && !isValidCableCode(r.cod_cable));
               } else if (filterColumn === 'de_manguito' && filterType === 'sleeveNotFound') {
                   d = d.filter(r => r.de_manguito && !isValidSleeveCode(r.de_manguito));
               } else {
                   d = d.filter(r => {
                       const v = r[filterColumn] || '';
                       if (!v || isKN(v)) return false;
                       if (filterType === 'notFound') return !isValidTerminalCode(v);
                       if (!r.seccion) return false;
                       const sc = checkSectionCompatibility(v, r.seccion);
                       return sc && !sc.ok;
                   });
               }
           }
 
           // 3. Ordenación
           if (currentSortCol) {
               d.sort((aRow, bRow) => {
                   let vA = aRow[currentSortCol] || '', vB = bRow[currentSortCol] || '';
                   const numA = parseFloat(String(vA).replace(',', '.')), numB = parseFloat(String(vB).replace(',', '.'));
                   let comp = (!isNaN(numA) && !isNaN(numB)) ? numA - numB : String(vA).localeCompare(String(vB), undefined, { numeric: true });
                   return sortAsc ? comp : -comp;
               });
           }
 
           // 4. Renderizado
           b.innerHTML = d.map(r => {
               const isFinished = isCableFinished(r.posicion);
               const isSelected = selectedMaterial && (r.de_terminal === selectedMaterial || r.para_terminal === selectedMaterial || r.de_manguito === selectedMaterial);
               const hasError = errorsMap[r.posicion] !== undefined;
               const rowClass = r.deleted ? 'row-deleted' : r.added ? 'row-added' : '';
               const isConnectionSelected = selectedConnectionPosition === String(r.posicion);
               
               return `<tr data-position="${encodeURIComponent(String(r.posicion))}" onclick="selectConnectionRow(event, this)" class="border-b border-sap-border dark:border-slate-700 text-left cursor-pointer ${isSelected?'bg-amber-100 dark:bg-blue-600/30':''} ${isConnectionSelected?'row-selected':''} ${isFinished?'row-completed':''} ${rowClass} ${hasError?'border-l-4 border-l-red-500 dark:border-l-red-500':''}">
                   ${a.map(c => {
                       if (c.key === 'status') {
                           return `<td class="p-3 text-center border-r border-sap-border/20">
                               <input type="checkbox" ${isFinished ? 'checked' : ''} disabled 
                               class="w-4 h-4 accent-[#10b981] opacity-70 cursor-not-allowed">
                           </td>`;
                       }
                       const changes = errorsMap[r.posicion] || {};
                       const changedValue = changes[c.key] !== undefined ? changes[c.key] : undefined;
                       const v = changedValue !== undefined ? changedValue : (r[c.key]||'');
                       const isElementCol = v && c.key.includes('_elemento');
                       const isCellModified = changedValue !== undefined || (c.key === 'orden' && r.orderChanged && !r.deleted);
                       const cellClass = isCellModified ? (c.key === 'orden' && r.orderChanged ? 'cell-order-changed' : 'cell-modified') : '';
                       const isTerminalCol = c.key === 'de_terminal' || c.key === 'para_terminal';
                       const termSC = isTerminalCol && v && v !== 'S/T' && !isKN(v) && r.seccion ? checkSectionCompatibility(v, r.seccion) : null;
                       const hasIncompat = termSC && !termSC.ok;
                       const hasTermNotFound = isTerminalCol && v && !isKN(v) && !isValidTerminalCode(v);
                       const hasCableNotFound = c.key === 'cod_cable' && v && !isValidCableCode(v);
                       const hasSleeveNotFound = c.key === 'de_manguito' && v && !isValidSleeveCode(v);
                       const isDupCell = (c.key === 'posicion' && _dupPosicions.has((r.posicion||'').toString().trim())) || (c.key === 'orden' && _dupOrdenes.has((r.orden||'').toString().trim()));
                       const dupTooltip = c.key === 'posicion' ? 'Posición duplicada — existe otra fila con el mismo valor' : 'Orden duplicada — existe otra fila con el mismo valor';
                       const _termHasVal = t => !!(t && t !== 'S/T' && t !== 'S/M' && !isKN(t));
                       const hasMissingSeccion = c.key === 'seccion' && !v && (_termHasVal(r.de_terminal) || _termHasVal(r.para_terminal));
                       const hasNonNumLong = c.key === 'longitud' && _nonNumericLongitud.has((r.posicion||'').toString().trim());
                       return `<td class="p-3 text-xs border-r border-sap-border/20 ${isElementCol?'font-bold text-sap-blue cursor-pointer hover:underline':''} ${cellClass} ${hasIncompat?'cell-incompat-blink':''} ${hasTermNotFound?'cell-notfound-blink':''} ${hasCableNotFound?'cell-cable-notfound-blink':''} ${hasSleeveNotFound?'cell-sleeve-notfound-blink':''} ${isDupCell?'cell-dup-blink':''} ${hasMissingSeccion?'cell-seccion-missing':''} ${hasNonNumLong?'cell-nonnum-blink':''}"
                                   style="width: ${c.width}px;" 
                                   ${isElementCol ? `onclick="applyTableFilter('${v}')"` : ''}>
                                   <div class="flex items-center gap-1 min-w-0 ${hasIncompat?'text-red-600 dark:text-red-400':''} ${hasTermNotFound?'text-pink-600 dark:text-pink-400':''} ${hasCableNotFound?'text-emerald-600 dark:text-emerald-400':''} ${hasSleeveNotFound?'text-[#a67c52] dark:text-[#d2ad82]':''} ${hasNonNumLong?'text-purple-600 dark:text-purple-400':''} ${isDupCell?'text-orange-600 dark:text-orange-400':''} ${hasMissingSeccion?'justify-center':''}">
                                       <span class="truncate">${v}</span>
                                       ${hasCableNotFound ? `<i data-lucide="triangle-alert" class="w-3 h-3 shrink-0 text-emerald-500 cursor-help" onmouseenter="showCellErrorTip(this,'emerald','ID CABLE NO EXISTE','El código de cable no está dado de alta en la base de datos.')" onmouseleave="hideCellErrorTip()" ontouchstart="showCellErrorTip(this,&quot;emerald&quot;,&quot;ID CABLE NO EXISTE&quot;,&quot;El código de cable no está dado de alta en la base de datos.&quot;); event.stopPropagation()"></i>` : ''}
                                       ${hasSleeveNotFound ? `<i data-lucide="triangle-alert" class="w-3 h-3 shrink-0 text-[#a67c52] cursor-help" onmouseenter="showCellErrorTip(this,'brown','DE MANGUITO NO EXISTE','El código de manguito no está dado de alta en la base de datos.')" onmouseleave="hideCellErrorTip()" ontouchstart="showCellErrorTip(this,&quot;brown&quot;,&quot;DE MANGUITO NO EXISTE&quot;,&quot;El código de manguito no está dado de alta en la base de datos.&quot;); event.stopPropagation()"></i>` : ''}
                                       ${hasIncompat ? `<i data-lucide="triangle-alert" class="w-3 h-3 shrink-0 text-red-500 cursor-help" onmouseenter="showTermCompatTip(this,'${v}','${r.seccion}','${termSC.validSections.join(', ')}')" onmouseleave="hideCellErrorTip()" ontouchstart="showTermCompatTip(this,'${v}','${r.seccion}','${termSC.validSections.join(', ')}'); event.stopPropagation()"></i>` : ''}
                                       ${hasTermNotFound ? `<i data-lucide="triangle-alert" class="w-3 h-3 shrink-0 text-pink-500 cursor-help" onmouseenter="showCellErrorTip(this,'pink','TERMINAL NO EXISTE','El terminal / pin no existe o no est\u00e1 dado de alta en la base de datos.')" onmouseleave="hideCellErrorTip()" ontouchstart="showCellErrorTip(this,&quot;pink&quot;,&quot;TERMINAL NO EXISTE&quot;,&quot;El terminal / pin no existe o no est\u00e1 dado de alta en la base de datos.&quot;); event.stopPropagation()"></i>` : ''}
                                       ${hasMissingSeccion ? `<i data-lucide="alert-circle" class="w-3 h-3 shrink-0 text-amber-600 dark:text-amber-400 cursor-help" onmouseenter="showCellErrorTip(this,'amber','SECCI\u00d3N OBLIGATORIA','La fila tiene terminal asignado pero la secci\u00f3n del cable no est\u00e1 definida.')" onmouseleave="hideCellErrorTip()" ontouchstart="showCellErrorTip(this,&quot;amber&quot;,&quot;SECCI\u00d3N OBLIGATORIA&quot;,&quot;La fila tiene terminal asignado pero la secci\u00f3n del cable no est\u00e1 definida.&quot;); event.stopPropagation()"></i>` : ''}
                                       ${hasNonNumLong ? `<i data-lucide="triangle-alert" class="w-3 h-3 shrink-0 text-purple-500 cursor-help" onmouseenter="showCellErrorTip(this,'purple','LONGITUD NO V\u00c1LIDA','El valor contiene caracteres no num\u00e9ricos. Revisa la columna E del Excel.')" onmouseleave="hideCellErrorTip()" ontouchstart="showCellErrorTip(this,&quot;purple&quot;,&quot;LONGITUD NO V\u00c1LIDA&quot;,&quot;El valor contiene caracteres no num\u00e9ricos. Revisa la columna E del Excel.&quot;); event.stopPropagation()"></i>` : ''}
                                       ${isDupCell ? `<i data-lucide="copy" class="w-3 h-3 shrink-0 text-orange-500 cursor-help" onmouseenter="showCellErrorTip(this,'orange','${c.key==='posicion'?'POSICI\u00d3N DUPLICADA':'ORDEN DUPLICADA'}','Existe m\u00e1s de una fila con este mismo valor en la columna.')" onmouseleave="hideCellErrorTip()" ontouchstart="showCellErrorTip(this,&quot;orange&quot;,&quot;${c.key==='posicion'?'POSICI\u00d3N DUPLICADA':'ORDEN DUPLICADA'}&quot;,&quot;Existe m\u00e1s de una fila con este mismo valor en la columna.&quot;); event.stopPropagation()"></i>` : ''}
                                   </div>
                               </td>`;
                   }).join('')}
                   <td class="p-1 text-center min-w-[5rem] border-l border-sap-border/30 dark:border-slate-700">
                       <button onclick="${incidenciaModeActive ? `openErrorModal('${r.posicion}')` : 'void(0)'}"
                           title="${incidenciaModeActive ? (hasError ? 'Editar incidencia registrada' : 'Registrar incidencia en esta línea') : 'Activa el modo incidencias para registrar'}"
                           class="w-7 h-7 rounded flex items-center justify-center transition-colors
                               ${!incidenciaModeActive
                                   ? 'text-slate-300 dark:text-slate-600 cursor-not-allowed'
                                   : hasError
                                       ? 'bg-red-300 dark:bg-red-600 text-red-600 dark:text-red-300 hover:bg-red-200'
                                       : 'bg-slate-50 border border-slate-200 text-slate-400 dark:bg-transparent dark:border-transparent hover:bg-sap-blue/10 hover:text-sap-blue'}">
                           <i class="fas ${hasError ? 'fa-exclamation-triangle' : 'fa-pencil-alt'} text-xs"></i>
                       </button>
                   </td>
               </tr>`;
           }).join('');
 
           // 5. Sidebar Materiales
           const sFilterTerms = filterText.trim() ? filterText.split('+').map(t => t.trim().toLowerCase()).filter(t => t) : [], matC = document.getElementById('elementMaterialsContainer');
           if (sFilterTerms.length > 0 && rawData.length > 0) {
               matC.classList.remove('hidden'); 
               const mats = {};
               rawData.forEach(r => { 
                   if (sFilterTerms.some(s => (r.de_elemento||'').toLowerCase() === s) && r.de_terminal && r.de_terminal !== 'S/T' && !isKN(r.de_terminal)) mats[r.de_terminal] = (mats[r.de_terminal]||0)+1; 
                   if (sFilterTerms.some(s => (r.para_elemento||'').toLowerCase() === s) && r.para_terminal && r.para_terminal !== 'S/T' && !isKN(r.para_terminal)) mats[r.para_terminal] = (mats[r.para_terminal]||0)+1; 
                   if (sFilterTerms.some(s => (r.de_elemento||'').toLowerCase() === s || (r.para_elemento||'').toLowerCase() === s) && r.de_manguito && r.de_manguito !== 'S/M') mats[r.de_manguito] = (mats[r.de_manguito] || 0) + 1; 
               });
              document.getElementById('terminalsBody').innerHTML = Object.entries(mats).map(([name, qty]) => `
    <div onclick="selectMaterial('${name}')" 
         class="px-2 py-1.5 border-b dark:border-slate-700 flex justify-between items-center cursor-pointer 
         ${selectedMaterial === name ? 'bg-amber-100 dark:bg-blue-600/30' : 'hover:bg-sap-blue/5 dark:hover:bg-slate-700/50'}">
        <div class="flex flex-col min-w-0 flex-1">
            <span class="text-[10px] font-bold text-sap-text dark:text-slate-100">${name}</span>
            <span class="text-[9px] text-sap-blue italic truncate">${masterMap.terminals[name]||masterMap.sleeves[name]||''}</span>
        </div>
        <span class="text-[10px] font-black bg-sap-blue/10 px-2 rounded-full text-sap-blue">${qty}</span>
    </div>`).join('');
           } else { matC.classList.add('hidden'); }
           lucide.createIcons();
       }
       window.onload = () => {
           // Título dinámico con versión
           document.title = `ICG Vision – V.${VERSION}`;
           const lv = document.getElementById('landingVersion');
           if (lv) lv.textContent = `V.${VERSION}`;
           const hmv = document.getElementById('helpModalVersion');
           if (hmv) hmv.textContent = `V.${VERSION}`;

           // 0. Cargar carpeta de autoguardado del Administrador (IndexedDB)
           _initAdminDirHandle();
           // 0b. Iniciar temporizador de autoguardado (cada 10 minutos si hay cambios)
           _startAutoSaveTimer();

           // 1. Recuperar tema persistido
           const savedTheme = localStorage.getItem('ICGVision_Theme');
           const themeLabel = document.getElementById('themeLabel');
           if (savedTheme === 'dark') {
               document.documentElement.classList.add('dark');
               if (themeLabel) themeLabel.innerText = 'Modo Claro';
           } else {
               document.documentElement.classList.remove('dark');
               if (themeLabel) themeLabel.innerText = 'Modo Oscuro';
           }
 
           // 2. Eventos de carga y filtros
           const fI = document.getElementById('csvInputLanding'); 
           if (fI) fI.addEventListener('change', handleFileUpload);
           
           document.getElementById('filterInput').addEventListener('input', (e) => { 
               filterText = e.target.value; 
               const isSingle = !!filterText.trim() && !filterText.includes('+');
               document.getElementById('elementQuickActions').classList.toggle('hidden', !isSingle); 
               updateView(); 
           });
           
           document.getElementById('filterMarcaInput').addEventListener('input', (e) => { 
               filterMarcaText = e.target.value; 
               updateView(); 
           });
           
           document.getElementById('globalSearchInput').addEventListener('input', () => { 
               currentMatchIdx = -1; 
           });
 
           // 3. Gestión de ratón (Panning y Resizing)
           window.addEventListener('mousemove', (e) => { 
               if (isPanning) { 
                   panX += e.movementX; 
                   panY += e.movementY; 
                   updateViewBox(); 
               } 
               if (resizingCol) { 
                   resizingCol.width = Math.max(50, startWidth + (e.clientX - startX)); 
                   updateView(); 
               } 
           });
 
           window.addEventListener('mouseup', () => { 
               isPanning = false; 
               resizingCol = null; 
           });
 
           // 4. Gestión del Diagrama SVG
           const s = document.getElementById('diagramSvg'); 
           if (s) {
               s.addEventListener('mousedown', (e) => { 
                   if (e.target.closest('.diag-block-pin, .diag-block-side, .diag-text-wire')) return; 
                   isPanning = true; 
                   hidePinPopover(); 
               });
               s.addEventListener('wheel', (e) => {
                   e.preventDefault();
                   adjustZoom(e.deltaY < 0 ? 1.1 : 0.9);
               }, { passive: false });
               s.addEventListener('touchstart', (e) => {
                   if (e.touches.length >= 2) {
                       // Pinch: prevenir que el navegador intercepte el gesto ANTES que el JS.
                       // Solo para 2+ dedos: no suprimir el click sintético de un tap.
                       e.preventDefault();
                       isPanning = false;
                       lastTouchDist = Math.hypot(
                           e.touches[0].clientX - e.touches[1].clientX,
                           e.touches[0].clientY - e.touches[1].clientY
                       );
                       lastTouchX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
                       lastTouchY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
                   } else {
                       // 1 dedo: iniciar pan pero NO prevenir default para que los
                       // taps sigan generando eventos click (onclick de pines/elementos).
                       isPanning = true;
                       lastTouchX = e.touches[0].clientX;
                       lastTouchY = e.touches[0].clientY;
                   }
               }, { passive: false });
               s.addEventListener('touchmove', (e) => {
                   e.preventDefault();
                   if (e.touches.length === 1 && isPanning) {
                       panX += (e.touches[0].clientX - lastTouchX);
                       panY += (e.touches[0].clientY - lastTouchY);
                       lastTouchX = e.touches[0].clientX;
                       lastTouchY = e.touches[0].clientY;
                       updateViewBox();
                   } else if (e.touches.length >= 2) {
                       const d = Math.hypot(
                           e.touches[0].clientX - e.touches[1].clientX,
                           e.touches[0].clientY - e.touches[1].clientY
                       );
                       const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
                       const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2;
                       // Pan por desplazamiento del punto medio entre los dos dedos
                       panX += cx - lastTouchX;
                       panY += cy - lastTouchY;
                       // Zoom proporcional a la distancia entre dedos
                       if (lastTouchDist > 0) adjustZoom(d / lastTouchDist);
                       lastTouchDist = d;
                       lastTouchX = cx;
                       lastTouchY = cy;
                   }
               }, { passive: false });
               s.addEventListener('touchend', (e) => {
                   if (e.touches.length === 0) {
                       isPanning = false;
                       lastTouchDist = 0;
                   } else if (e.touches.length === 1) {
                       // Queda un dedo: reanudar pan desde su posición actual
                       isPanning = true;
                       lastTouchX = e.touches[0].clientX;
                       lastTouchY = e.touches[0].clientY;
                       lastTouchDist = 0;
                   }
               });
           }
           lucide.createIcons();
       };
 
       // --- FUNCIONES DEL MAPA DE PROGRESO ---
       function openProgressMap() {
           const grid = document.getElementById('elementGrid');
           if (!grid || rawData.length === 0) return;
           grid.innerHTML = '';
           
           // 1. Identificar todos los elementos únicos presentes en el informe
           const allElements = new Set();
           rawData.forEach(row => {
               if (row.de_elemento) allElements.add(row.de_elemento);
               if (row.para_elemento) allElements.add(row.para_elemento);
           });
 
           const sortedElements = Array.from(allElements).sort();
 
           sortedElements.forEach(elName => {
               const s = elName.toLowerCase();
               const relatedRows = rawData.filter(row => 
                   (row.de_elemento || '').toLowerCase() === s || 
                   (row.para_elemento || '').toLowerCase() === s
               );
               
               // 2. Contar cables únicos (usando un Set por ID de posición)
               const uniqueCableIds = new Set(relatedRows.map(r => r.posicion));
               const totalCount = uniqueCableIds.size;
               
               // 3. Contar cuántos de esos cables únicos están terminados para este elemento
               let completedCount = 0;
               uniqueCableIds.forEach(pos => {
                   const row = rawData.find(r => r.posicion === pos);
                   const prog = progressMap[pos] || { de: false, para: false };
                   
                   // Lógica específica para puente: si es origen y destino, ambos lados OK
                   const esOrigen = (row.de_elemento || '').toLowerCase() === s;
                   const esDestino = (row.para_elemento || '').toLowerCase() === s;
                   
                   if (esOrigen && esDestino) {
                       if (prog.de && prog.para) completedCount++;
                   } else if (esOrigen) {
                       if (prog.de) completedCount++;
                   } else if (esDestino) {
                       if (prog.para) completedCount++;
                   }
               });
 
               // 4. Calcular estado visual
               const isFinished = totalCount > 0 && completedCount >= totalCount;
               const isInProgress = completedCount > 0 && completedCount < totalCount;
               
               let cardClass = isFinished ? 'bg-emerald-500 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)] text-white' : 
                               (isInProgress ? 'bg-purple-100 dark:bg-purple-900/40 border-purple-300 text-purple-700 dark:text-purple-200' : 
                               'bg-white dark:bg-slate-800 border-sap-border text-sap-text dark:text-slate-300');
               
               let statusText = isFinished ? 'Terminado' : (isInProgress ? 'En curso' : 'Pendiente');
               
               const card = document.createElement('div');
               card.className = `p-3 rounded-lg border text-center transition-all duration-300 cursor-pointer ${cardClass}`;
               
               card.innerHTML = `
                   <div class="text-[8px] font-black uppercase tracking-tighter opacity-80">
                       ${statusText} ${isInProgress ? `(${completedCount}/${totalCount})` : ''}
                   </div>
                   <div class="font-bold text-xs truncate">${elName.toUpperCase()}</div>
               `;
               
               card.onclick = () => { applyTableFilter(elName); closeProgressMap(); };
               grid.appendChild(card);
           });
 
           document.getElementById('progressMapModal').classList.remove('hidden');
           if (window.lucide) lucide.createIcons();
       }
 
       function closeProgressMap() {
           document.getElementById('progressMapModal').classList.add('hidden');
       }
        function openGraphicalViewFromVision() {
   // 1. Cerramos el modo visión
   document.getElementById('detailModal').classList.add('hidden');
   // 2. Ejecutamos la apertura del gráfico usando el elemento actual que está en el título
   const currentEl = document.getElementById('detailElementName').innerText;
   filterText = currentEl; // Actualizamos el filtro para que el gráfico sepa qué mostrar
   openGraphicalView();
}
 
   // Cerrar dropdowns de incidencias, ajustes y columnas al hacer clic fuera
   document.addEventListener('click', function(e) {
       // Dropdown navbar principal
       const container = document.getElementById('incidenciasMenuContainer');
       const dd = document.getElementById('incidenciasDropdown');
       if (container && dd && !container.contains(e.target) && !dd.classList.contains('hidden')) {
           dd.classList.add('hidden');
           document.getElementById('btnIncidencias')?.classList.remove('bg-red-500/10');
       }
       // Dropdown modo visión
       const vContainer = document.getElementById('visionIncidenciasMenuContainer');
       const vDd = document.getElementById('visionIncidenciasDropdown');
       if (vContainer && vDd && !vContainer.contains(e.target) && !vDd.classList.contains('hidden')) {
           vDd.classList.add('hidden');
           document.getElementById('btnVisionIncidencias')?.classList.remove('bg-red-500/80');
       }
       // Dropdown vista móvil
       const mvContainer = document.getElementById('mobileViewMenuContainer');
       const mvDd = document.getElementById('mobileViewDropdown');
       if (mvContainer && mvDd && !mvContainer.contains(e.target) && !mvDd.classList.contains('hidden')) {
           mvDd.classList.add('hidden');
       }
       // Dropdown menú de ajustes (Corregido con doble validación)
       const settingsBtn = document.getElementById('btnSettings');
       const settingsDd = document.getElementById('settingsDropdown');
       if (settingsBtn && settingsDd && !settingsBtn.contains(e.target) && !settingsDd.contains(e.target) && !settingsDd.classList.contains('hidden')) {
           settingsDd.classList.add('hidden');
       }
       // Dropdown personalizar columnas - MEJORADO
       const columnsBtn = document.getElementById('btnColumns');
       const columnsDd = document.getElementById('colConfigDropdown');
       if (columnsDd && !columnsDd.classList.contains('hidden')) {
           // Si el click NO está dentro del botón NI dentro del dropdown, lo cerramos
           if (!columnsBtn?.contains(e.target) && !columnsDd.contains(e.target)) {
               columnsDd.classList.add('hidden');
           }
       }
      }, true);
    window.addEventListener('beforeunload', function (e) {
   if (hasUnsavedChanges) {
       e.preventDefault();
       e.returnValue = '';
   }
});
 
